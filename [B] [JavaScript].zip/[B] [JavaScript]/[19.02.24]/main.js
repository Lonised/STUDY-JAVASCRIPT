//  const container = document.querySelector(".container");
//  
//  const data = null;
//  const data = [
//      {
//          country: "KZ",
//          capital: "Astana"   
//      },
//      {
//          country: "RU",
//          capital: "Moscow"
//      },
//      {
//          country: "France",
//          capital: "Paris"
//      },
//  ]

// JSON - передача данных с помощью этой программы. Осуществляется между клиентом и сервером
//  stringify - переводит из объекта в JSON строку 
//  onst jsonString = JSON.stringify(data);
//  
//  onsole.log(jsonString);
//  onsole.log(typeof(jsonString));
//  
//  /  console.log(JSON.stringify(data));
//  /  console.log(typeof(JSON.stringify(data)));
//  
//  /  parse - переводит из JSON строки в объект 
//  onsole.log(JSON.parse(jsonString));
//  
//  const showData = (data) => {
//      data.map((country) => {
//          console.log(country);
//          const div = document.createElement("div");
//          const countryName = country.country;
//          const capitalName = country.capital;
//          div.append(countryName);
//          div.append(capitalName);
//    
//            
//          container.append(div);
//      });
//  }
//  
//  const saveData = (data, dataName) => {
//      localStorage.setItem(dataName, JSON.stringify(data));
//  }
//  
//  const dataFromLocalStorage = JSON.parse(localStorage.getItem("countriesData"));
//  console.log(dataFromLocalStorage);


//  // Два варианта проверки данных 
//  data ? showData(data) : showData(dataFromLocalStorage);
//  showData(data || dataFromLocalStorage);

//  showData(data);
//  
//  saveData(data, "countriesData");

//  Удалит все записи с локал стореджа
//  localStorage.clear()

//  Удалит одну запись по ключу
//  localStorage.removeItem("test");

const goodsContainer = document.querySelector(".goods-container");
const confirmOrderBtn = document.querySelector(".buy-btn");
const checkList = document.querySelector(".check-list");
const checkId = document.querySelector(".check-id");

const cart = {
    data: [],
    total: 0,
}

const getTotalPrice = () => {
    let sum = 0;
    for (let i = 0; i < cart.data.length; i++) {
        sum += cart.data[i].totalPrice;
    }
    return sum;
}

const addToCart = (event) => {
    const target = event.target;
    // Если кликнули на элемнт, с таким классом, то этот элемент запишется в переменную, иначе null
    const buyBtn = target.closest(".good-btn");

    // if (butBtn) {...}
    if (buyBtn != null) {
        const card = target.parentElement;
        const cardTitle = card.dataset.title;
        const cardPrice = card.dataset.price;

        const existingItem = cart.data.find((item) => item.title === cardTitle);
        console.log(existingItem);

        if (existingItem) {
            existingItem.amount += 1;
            existingItem.totalPrice = existingItem.amount * existingItem.price;
        } else {
            const cardObj = {
                title: cardTitle,
                price: cardPrice,
                amount: 1,
                totalPrice: +cardPrice,
            }
            cart.data.push(cardObj);
        }
        
        console.log(cart);
    }

}

const generateCheck = () => {
    const checkId = Math.floor(Math.random() * 9999);
    const checkDate = Date.now();

    checkId.textContent = checkIdValue;
    
    cart.data.map((good) => {
        const li = document.createElement("li");
        li.textContent = `${good.title} - ${good.price} - ${good.amount}`;
        checkList.append(li);
    })


}




goodsContainer.addEventListener("click", addToCart);
confirmOrderBtn.addEventListener("click", generateCheck)