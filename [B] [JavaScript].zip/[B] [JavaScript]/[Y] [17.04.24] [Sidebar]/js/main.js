const sidebar = document.querySelector(".sidebar");
const main = document.querySelector(".main");
const categories = document.querySelector(".categories");

const serverURL = 'http://172.28.0.246:9999';

document.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
        sidebar.style.position = "fixed";
    } else {
        sidebar.style.position = "";
    }
});

sidebar.addEventListener("click", (e) => {
    if (!e.target.closest(".categories")) {
        sidebar.style.width = sidebar.style.width === "15%" ? "10%" : "15%";
        main.style.marginLeft = sidebar.style.width === "15%" ? "15%" : "10%";
    }
});

categories.addEventListener("click", (e) => {
    const target = e.target;

    if (target.closest(".category")) {
        //console.log("Clicked:", target.textContent); // Для проверки.
        //Или можно записать console.log(target);

        const subcategories = target.querySelector(".subcategories");
        if (subcategories) {
            subcategories.classList.toggle("hide");
        }

    }

    //console.log(target);

});



const createSubCategories = (subcategoriesArr, subcategoriesWrapper) => {
    subcategoriesArr.forEach(element => {
        const subcategory = `<div class="subcategory">${element.name} </div>`;
        subcategoriesWrapper.insertAdjacentHTML("beforeend", subcategory)
    });
}

const createCategories = (categoriesArr) => {
    categoriesArr.forEach(element => {
        const subcategoriesArr = element.subcategories;

        const categoryElem = document.createElement("div");

        categoryElem.classList.add("category")
        categoryElem.textContent = element.name;
        
        if (subcategoriesArr.length > 0) {
            const subcategoriesWrapper = document.createElement("div");

            subcategoriesWrapper.classList.add("subcategories");
            subcategoriesWrapper.classList.add("hide");
            categoryElem.append(subcategoriesWrapper);
            createSubCategories(subcategoriesArr, subcategoriesWrapper);
        }

        categories.append(categoryElem);
    });
}

const getCategories = async () => {
    try {
        const res = await fetch(`${serverURL}/products/category`, {
            method: "GET",
            headers: {
                'accept': 'application/json',
            }
        })


        if (res.ok) {
            const data = await res.json();
            return data.categories;
        }
    } catch (error) {
        throw new Error(error);
    }
}

const init = async () => {
    const categoriesArr = await getCategories();

    createCategories(categoriesArr);
}

init();