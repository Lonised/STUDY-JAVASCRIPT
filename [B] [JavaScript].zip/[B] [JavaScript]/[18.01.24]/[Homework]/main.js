// 1

//  const возраст = prompt('Введите ваш возраст:');
//  
//  if (возраст >= 0 && возраст <= 2) {
//      alert('Вы ребенок.');
//  } else if (возраст >= 12 && возраст < 18) {
//      alert('Вы подросток.');
//  } else if (возраст >= 18 && возраст < 60) {
//      alert('Вы взрослый.');
//  } else if (возраст >= 60) {
//      alert('Вы пенсионер.');
//  } else {
//      alert('Пожалуйста, введите корректный возраст.');
//  }


// 2 

//  const введенное_число = prompt('Введите число от 0 до 9:');
//  
//  switch (введенное_число) {
//      case '0':
//          alert('На клавише "0" расположен спецсимвол: )');
//          break;
//      case '1':
//          alert('На клавише "1" расположен спецсимвол: !');
//          break;
//      case '2':
//          alert('На клавише "2" расположен спецсимвол: @');
//          break;
//      case '3':
//          alert('На клавише "3" расположен спецсимвол: #');
//          break;
//      case '4':
//          alert('На клавише "4" расположен спецсимвол: $');
//          break;
//      case '5':
//          alert('На клавише "5" расположен спецсимвол: %');
//          break;
//      case '6':
//          alert('На клавише "6" расположен спецсимвол: ^');
//          break;
//      case '7':
//          alert('На клавише "7" расположен спецсимвол: &');
//          break;
//      case '8':
//          alert('На клавише "8" расположен спецсимвол: *');
//          break;
//      case '9':
//          alert('На клавише "9" расположен спецсимвол: (');
//          break;
//      default:
//          alert('Пожалуйста, введите число от 0 до 9.');
//  }


// 3 

//  const num3 = prompt('Введите трехзначное число:');
//  if (!isNaN(num3) && num3.length === 3) {
//  
//      const num3a = Math.floor(num3 / 100);
//      const num3b = Math.floor((num3 % 100) / 10);
//      const num3c = num3 % 10;
//  
//      if (num3a === num3b || num3a === num3c || num3b === num3c) {
//          alert('В числе есть одинаковые цифры.');
//      } else {
//          alert('В числе нет одинаковых цифр.');
//      }
//  } else {
//      alert('Пожалуйста, введите корректное трехзначное число.');
//  }


// 4

//  let year = +prompt("Введите год")
//  if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ){
//      console.log("Високосный");
//  } else {
//      console.log("Не високосный");
//  }


// 5 

//  const num5 = prompt('Введите пятизначное число:');
//  
//  if (!isNaN(num5) && num5.length === 5) {
//  
//      const num5a = num5.toString();
//  
//      // Сравниваем символы с начала и с конца строки
//      if (num5a[0] === num5a[4] && num5a[1] === num5a[3]) {
//          alert('Это палиндром.');
//      } else {
//          alert('Это не палиндром.');
//      }
//  } else {
//      alert('Пожалуйста, введите корректное пятизначное число.');
//  }


// 6

//  const EUR = 0.85;
//  const UAN = 28.5;
//  const AZN = 1.7;
//  
//  const USD = prompt('Введите количество USD:');
//  const num6 = prompt('Выберите валюту для конвертации (EUR, UAN, AZN):').toUpperCase();
//  
//  let результат;
//  
//  switch (num6) {
//      case 'EUR':
//          результат = USD * EUR;
//          alert(`Сумма в ${num6}: ${результат.toFixed(2)}`);
//          break;
//      case 'UAN':
//          результат = USD * UAN;
//          alert(`Сумма в ${num6}: ${результат.toFixed(2)}`);
//          break;
//      case 'AZN':
//          результат = USD * AZN;
//          alert(`Сумма в ${num6}: ${результат.toFixed(2)}`);
//          break;
//      default:
//          alert('Пожалуйста, выберите корректную валюту (EUR, UAN, AZN).');
//  }


// 7 

//  const num7a = prompt('Введите сумму покупки:');
//  
//  if (!isNaN(num7a)) {
//      const num7b = parseFloat(num7a);
//  
//      let скидка = 0;
//  
//      if (num7b >= 200 && num7b < 300) {
//          скидка = 0.03;
//      } else if (num7b >= 300 && num7b < 500) {
//          скидка = 0.05;
//      } else if (num7b >= 500) {
//          скидка = 0.07;
//      }
//  
//      const num7c = num7b * (1 - скидка);
//  
//      alert(`Сумма к оплате со скидкой: ${num7c.toFixed(2)}`);
//  } else {
//      alert('Пожалуйста, введите корректную сумму покупки.');
//  }


// 8

//  const num8a = prompt('Введите длину окружности:');
//  const num8b = prompt('Введите периметр квадрата:');
//  
//  if (!isNaN(num8a) && !isNaN(num8b)) {
//      const num8c = num8a / (2 * Math.PI);
//      const num8d = num8b / 4;
//  
//      if (num8c <= num8d) {
//          alert('Окружность может поместиться внутри квадрата.');
//      } else {
//          alert('Окружность не поместится внутри квадрата.');
//      }
//  } else {
//      alert('Пожалуйста, введите корректные значения.');
//  }


// 9

//  let num9 = 0;
//  
//  const num9a = prompt('Вопрос 1: Какой язык программирования используется для создания веб-страниц?\n1. Java\n2. Python\n3. JavaScript');
//  if (num9a === '3') {
//      num9 += 2;
//  }
//  
//  const num9b = prompt('Вопрос 2: Какое число является основой системы счисления в компьютерах?\n1. 8\n2. 10\n3. 16');
//  if (num9b === '2') {
//      num9 += 2;
//  }
//  
//  const num9c = prompt('Вопрос 3: Кто является автором теории относительности?\n1. Ньютон\n2. Эйнштейн\n3. Галилео');
//  if (num9c === '2') {
//      num9 += 2;
//  }
//  
//  alert(`Вы набрали ${num9} баллов.`);


// 10

//  const num10a = parseInt(prompt('Введите день:'));
//  const num10b = parseInt(prompt('Введите месяц (число от 1 до 12):'));
//  const num10c = parseInt(prompt('Введите год:'));
//  
//  if (!isNaN(num10a) && !isNaN(num10b) && !isNaN(num10c)) {
//      const mun10aa = new Date(num10c, num10b, 0).getDate();
//  
//  
//      if (num10a >= 1 && num10a <= mun10aa && num10b >= 1 && num10b <= 12) {
//  
//          let num10bb = new Date(num10c, num10b - 1, num10a);
//          num10bb.setDate(num10bb.getDate() + 1);
//  
//  
//          alert(`Следующая дата: ${num10bb.getDate()}.${num10bb.getMonth() + 1}.${num10bb.getFullYear()}`);
//      } else {
//          alert('Пожалуйста, введите корректные значения для дня, месяца и года.');
//      }
//  } else {
//      alert('Пожалуйста, введите корректные числовые значения.');
//  }






