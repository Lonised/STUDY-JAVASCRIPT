//  let number = 10;
//  let text = "Hello";
//  let isRed = false;
//  
//  // ! = отприцание НЕ. Приводит к логичскому типу данных 
//  console.log(typeof(number)); // number 
//  console.log(!number); // false
//  console.log(typeof(!number)); // boolean 
//  
//  let text1 = ""
//  console.log(!!number); // 10 -> false -> true 
//  console.log(!text1); // true 
//  console.log(!isRed); // true  



//  let a = 10; // true 
//  let b = 20; // true  
//  let c = 0;  // false
//  
//  console.log(!!c && !!b); 
//  console.log(!!c || !!b);

//  let num1 = +prompt("Число 1");
//  let num2 = +prompt("Число 2");

//  Если выражение в круглых скобках будет true = то делай то, что написано в фигурных скобках 
//  if (num1 > num2) {
//      console.log("Число 1 больше, чем число 2");
//  } else if (num1 < num2) {
//      console.log("Число 1 больше, чем число 2");
//  } else if (num1 === num2) {
//      console.log("Они равны");
//  } else {
//      console.log("Ошибка");
//  }

//  let num = +prompt("Введите число");
//  
//  if (num >= 100) {
//      console.log("Число больше или равно 100");
//  } else if (num < 100) {
//      console.log("Число меньше 100");
//  }









//3 
//  let num = +prompt("Введите число: ")
//  if (num > 0) {
//      console.log("Число положительное");
//  } else if (num < 0) {
//      console.log("Число отрицательное ");
//  }

//4 
//  let num1 = +prompt("Введите первое число: ");
//  let num2 = +prompt("Введите второе число: ");
//  if (num1 > num2) {
//      console.log("Первое число больше на = ", num1 - num2 );
//  } else if (num1 < num2) {
//      console.log("Error");
//  } else {
//      console.log("Error");
//  }

//5 
//  let num1 = +prompt("Введите A: ");
//  let num2 = +prompt("Введите B: ");
//  if (num1 == num2) {
//      console.log("A = ", num1 + num2, "B = ", num1 + num2);
//  } else if (num1 != num2) {
//      console.log("A = ", 0, "B = ", 0);
//  }

// 6
//  let num = +prompt("Введите число: ")
//  if (num % 2 == 0) {
//      console.log("Число положительное ");
//  } else {
//      console.log("Число отрицательное ");
//  }


//  let year = +prompt("Введите год")
//  if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ){
//      console.log("Високосный");
//  } else {
//      console.log("Не високосный");
//  }


//  let a = +prompt();
//  let b = +prompt();
//  let c = +prompt();
//  let d = +prompt();
//  
//  if (a > b && a > c && a > d) {
//      console.log("Число а самое большое");
//  } else if (b > a && b > c && b > d) {
//      console.log("Число б самое большое");
//  } else if (c > a && c > b && c > d) {
//      console.log("Число c самое большое");
//  } else if (d > a && d > b && d > c) {
//      console.log("Число d самое большое");
//  } else {
//      console.log("Числа равны");
//  }

//  let number = +prompt();
//  0 < number < 30 
//  if (number > 0 && number < 30) {
//      console.log("Привет");
//  } else {
//      console.log("Пока");
//  }


//  let userName = prompt("Введите имя");
//  switch (userName) {
//      case "Alex":
//          console.log("Hello Alex");
//          break;
//      case "Ivan":
//      console.log("Hello Ivan");
//  
//      default:
//          console.log("Hello");
//          break;
//  } 


//  let day = prompt("Введите день недели");
//  switch (day) {
//      case "Четверг":
//          console.log("Верно");
//          break;
//  
//      default:
//          console.log("Не верно");
//          break;
//  } 



//  let day = prompt("Введите день недели");
//  switch (day) {
//      case "Понедельник":
//          console.log("Проснуться");
//          break;
//      case "Вторник":
//          console.log("Не умереть");
//          break;
//      case "Среда":
//          console.log("Сегодня точно нельзя умирать");
//          break;
//      case "Четверг":
//          console.log("Можно почилить");
//          break;
//      case "Пятница":
//          console.log("Сегодня нельзя умирать");
//          break;
//      case "Суббота":
//          console.log("Отдыхай, пока можешь");
//          break;
//      case "Воскресенье":
//          console.log("Отдыхай, завтра ад");
//          break;
//  
//      default:
//          console.log("Ты че ?");
//          break;
//  } 

//  //Округляет дробное число до ближайшего меньше целого числа
//  console.log(Math.floor(0.9));
//  //Округляет математически
//  console.log(Math.round(0.9));
//  //Округляет до ближайшего большего целого числа 
//  console.log(Math.ceil(0.9));
//  
//  
//  
//  // Получаем случайное число от 0 до 1 с дробной частью 
//  console.log(Math.random() * 10); 
//  
//  //Модуль числа
//  console.log(Math.abs(-5));
//  //Корень числа
//  console.log(Math.sqrt(25));
//  //Три в четвертой степени 
//  console.log(Math.pow(3, 4));

//  let text = "Lorem ipsum dollar"
//  
//  // Возвращает длину строки 
//  console.log(text.length);
//  // Приводит строку в нижний регистр
//  console.log(text.toLowerCase());
//  // Приводит строку в верхний регистр
//  console.log(text.toUpperCase());
//  
//  // Находит слово Lorem и замменяте его на Привет 
//  console.log(text.replace("Lorem", "Привет"));
//  
//  
//  text = text.replace("dollar", "тенге")
//  console.log(text);




let text = prompt("Введите месяц года");
switch (text) {
    case "Январь":
        text = text.replace("Январь", "January")
        console.log("Январь = ", text);
        break;
    case "Февраль":
        text = text.replace("Февраль", "February")
        console.log("Февраль = ", text);
        break;
    case "Март":
        text = text.replace("Март", "March")
        console.log("Март = ", text);
        break;
    case "Апрель":
        text = text.replace("Апрель", "April")
        console.log("Апрель = ", text);
        break;
    case "Май":
        text = text.replace("Май", "May")
        console.log("Май = ", text);
        break;
    case "Июнь":
        text = text.replace("Июнь", "June")
        console.log("Июнь = ", text);
        break;
    case "Июль":
        text = text.replace("Июль", "July")
        console.log("Июль = ", text);
        break;
    case "Август":
        text = text.replace("Август", "August")
        console.log("Август = ", text);
        break;
    case "Сентябрь":
        text = text.replace("Сентябрь", "September")
        console.log("Сентябрь = ", text);
        break;
    case "Октябрь":
        text = text.replace("Октябрь", "Octomber")
        console.log("Октябрь = ", text);
        break;
    case "Ноябрь":
        text = text.replace("Ноябрь", "November")
        console.log("Ноябрь = ", text);
        break;
    case "Декабрь":
        text = text.replace("Декабрь", "December")
        console.log("Декабрь = ", text);
        break;

    default:
        console.log("Ты че ?");
        break;
} 
