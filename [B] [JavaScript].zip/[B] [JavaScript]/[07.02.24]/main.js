//  const boxNodes = document.getElementsByClassName("box");
//  
//  console.log(boxNodes);
//  console.log(boxNodes[0]);
//  console.log(boxNodes.length);
//  
//  const secondBox = document.getElementById("second");
//  
//  console.log(secondBox);
//  
//  const elemsByTag = document.getElementsByTagName("a");
//  
//  console.log(elemsByTag);
//  
//  // const secondBoxListItems = document.getElementsByTagName("li");
//  const secondBoxListItems = secondBox.getElementsByTagName("li");
//  console.log(secondBoxListItems);

//  const box = document.querySelector(".box");
//  const box1 = document.querySelector("#second");
//  
//  const boxList = document.querySelector("ul");
//  
//  console.log(box);
//  console.log(box1);
//  console.log(boxList);
//  
//  const boxes = document.querySelectorAll(".box");
//  console.log(boxes);
//  
//  const test = document.querySelectorAll("#second");
//  console.log(test);
//  
//  const boxThird = document.querySelector(".box-3");
//  
//  const boxThirdList = boxThird.querySelector("ul");
//  console.log(boxThirdList);
//  
//  
//  console.log(boxThird.textContent);
//  boxThird.textContent = "New value";
//  
//  box.textContent = "Text from Js.";
//  box.textContent += "Hello everyone!";
//  
//  box.innerHTML += "This is innerHTML";
//  
//  box1.textContent = " <a href='google.com'> textContent </a>"
//  box1.innerHTML += " <a href='google.com'> innerHTML </a>"
//  
//  
//  boxThird.style.background = "green";
//  boxThird.style.width = "200px";
//  boxThird.style.height = "200px";
//  boxThird.style.marginLeft = "10px";
//  boxThird.style.borderTopLeftRadius = "10px";
//  boxThird.style.border = "2px solid red";
//  boxThird.style.opacity = "0"; //Прозрачность 


//__________________________________________________________________//

//  const elemStyle = {
//      width: null,
//      height: null,
//      color: null,
//      border: {
//          borderWidth: null,
//          borderStyle: "solid",
//          borderColor: null,
//      },
//  }
//  
//  
//  
//  
//  for (const cssProp in elemStyle) {
//      if (cssProp == "border") {
//          for (const borderProp in elemStyle["border"]) {
//              let borderValue = prompt();
//              elemStyle["border"][borderProp] = borderValue; 
//          }
//      } else {
//          let value = prompt(`введите значение для ${cssProp}`);
//          elemStyle[cssProp] = value;
//      }
//      
//  }
//  console.log(elemStyle);
//  
//  const elem = document.querySelector(".elem");
//  const applyStyles = (obj) => {
//      elem.style.width = obj.width + "px";
//      elem.style.height = obj.height + "px";
//      elem.style.backgroundColor = obj.color;
//      elem.style.border = obj.border.borderWidth + "px " + 
//                          obj.border.borderStyle + " " + 
//                              obj.border.borderColor;
//  } 
//  
//  applyStyles(elemStyle);

const listItems = document.querySelectorAll("li");

for (let i = 0; i < listItems.length; i++) {
    console.log(listItems.length[i]);
    let liValue = Math.floor(Math.random() * 100);
    listItems[i].textContent = liValue;

    if (liValue > 70 ) {
        listItems[i].style.color = "green";
        listItems[i].style.fontSize = "20px";
    } else {
        listItems[i].style.color = "red";
        listItems[i].style.fontSize = "20px";
    }
    listItems[i].textContent = liValue

}




//  listItems.forEach((elem) => {
//      let liValue = Math.floor(Math.random() * 100);
//      if (liValue > 70 ) {
//          elem.style.color = "green";
//          elem.style.fontSize = "20px";
//      } else {
//          elem.style.color = "red";
//          elem.style.fontSize = "20px";
//      }
//      elem.textContent = liValue
//  })






let num = +prompt();
for (let i = 0; i < listItems.length; i++) {
    console.log((i + 1) * num);
    const tagLi = listItems[i];
    tagLi.textContent = `${num} * ${i + 1} = ${num * (i + 1)}`;
}