// 1

//  let start = +prompt("Введите начало диапазона:");
//  let end = +prompt("Введите конец диапазона:");
//  
//  let sum = 0;
//  
//  while (start <= end) {
//      sum += start;
//      start++;
//  }
//  
//  console.log("Сумма чисел в заданном диапазоне:", sum);


// 2

//  let num1 = +prompt("Введите первое число:");
//  let num2 = +prompt("Введите второе число:");
//  
//  let a = num1;
//  let b = num2;
//  
//  while (b !== 0) {
//      let temp = b;
//      b = a % b;
//      a = temp;
//  }
//  
//  console.log("Наибольший общий делитель:", a);


// 3

//  let number = +prompt("Введите число:");
//  
//  let i = 1;
//  while (i <= number) {
//      if (number % i === 0) {
//          console.log(i);
//      }
//      i++;
//  }
//  console.log("Все делители числа");


// 4

//  let num1 = +prompt("Введите число:");
//  let sum1 = 0;
//  let num2 = Math.abs(num1); 
//  
//  
//  while (num2 > 0) {
//      num2 = Math.floor(num2 / 10);
//      sum1++;
//  }
//  
//  console.log(" Количество цифр в числе ", sum1);


// 5

//  let positive = 0;
//  let negative = 0;
//  let zero = 0;
//  let even = 0;
//  let odd = 0;
//  
//  for (let i = 0; i < 10; i++) {
//      let userInput = +prompt("Введите число: ") || 0;
//  
//      if (userInput > 0) {
//          positive++;
//      } else if (userInput < 0) {
//          negative++;
//      } else {
//          zero++;
//      }
//  
//      if (userInput % 2 === 0) {
//          even++;
//      } else {
//          odd++;
//      }
//  }
//  
//  console.log("Положительные числа:", positive);
//  console.log("Отрицательные числа:", negative);
//  console.log("Нули:", zero);
//  console.log("Четные числа:", even);
//  console.log("Нечетные числа:", odd);


// 6 

//  let isContinued = true;
//  
//  while (isContinued) {
//      let num1 = +prompt("Введите первое число:") || 0;
//      let operator = prompt("Введите оператор (+, -, *, /):");
//      let num2 = +prompt("Введите второе число:") || 0;
//  
//      let result;
//  
//      if (operator === "+") {
//          result = num1 + num2;
//      } else if (operator === "-") {
//          result = num1 - num2;
//      } else if (operator === "*") {
//          result = num1 * num2;
//      } else if (operator === "/") {
//          result = num2 !== 0 ? num1 / num2 : "Деление на ноль!";
//      } else {
//          result = "Неверный оператор!";
//      }
//  
//  
//      console.log(`Результат: ${result}`); //Узнал об этом в интернете, как использовать $
//  
//      isContinued = confirm("Хотите решить еще один пример?");
//  }
//  
//  console.log("Спасибо за использование калькулятора! Больше не задавайте таких заданий( ");


// 7 

//  let input = prompt("Введите число:");
//  let shift = parseInt(prompt("На сколько цифр сдвинуть число:")); //Преобразует первый переданный ей аргумент в строковый тип, интерпретирует и возварщает целое число. 
//  let digits = input.split('').map(Number); //Короче, дает возможно создать функцию сдвига
//  
//  
//  for (let i = 0; i < shift; i++) {
//      let shiftedDigit = digits.shift();
//      digits.push(shiftedDigit);
//  }
//  
//  let resultNumber = parseInt(digits.join(''));
//  console.log(`Результат сдвига числа ${input} на ${shift} цифр(ы): ${result}`);


// 8 

//  const daysOfWeek = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];
//  let index = 0;
//  let Choose = true;
//  
//  while (Choose) {
//      Choose = confirm(`${daysOfWeek[index]}. Хотите увидеть следующий день?`);
//  
//      index = (index + 1) % 7;
//  }
//  
//  console.log("Твоя жизнь - твое решение...");


// 9

//  for (let i = 2; i <= 9; i++) {
//      console.log("Таблица умножения для " + i + ":");
//      for (let j = 1; j <= 10; j++) {
//          console.log(i + " * " + j + " = " + (i * j));
//      }
//      console.log();
//  }


// 10

//  let minRange = 0;
//  let maxRange = 100;
//  let guess;
//  
//  console.log("Загадайте число от 0 до 100.");
//  
//  while (true) {
//      guess = Math.floor((minRange + maxRange) / 2);
//  
//      let userAnswer = prompt("Ваше число > " + guess + ", < " + guess + " или == " + guess + "? (Введите >, < или ==)");
//  
//      if (userAnswer === ">") {
//          minRange = guess + 1;
//      } else if (userAnswer === "<") {
//          maxRange = guess - 1;
//      } else if (userAnswer === "==") {
//          console.log("Ваше число - " + guess + "!");
//          break;
//      } else {
//          console.log("Ты чё ? Нормально введи >, < или == ");
//      }
//  }