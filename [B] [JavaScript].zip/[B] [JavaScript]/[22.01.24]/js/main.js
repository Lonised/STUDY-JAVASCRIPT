//  let number = 5;
//  // number = number + 1; //
//  // == //
//  
//  number += 10;
//  
//  console.log(number); // 15
//  
//  number -= 2;
//  console.log(number); // 13
//  
//  number *= 1.5;
//  console.log(number); // 19.5
//  
//  number /= 2;
//  console.log(number); // 9.75
//  
//  
//  number++; // +1 к текущему значению
//  console.log(number);
//  
//  number--; // -1 от текущего значения
//  console.log(number);


//  let num = 1;
//  while (num <= 10) {
//      if (num == 6) {
//          console.log("Сработал if, мы дошли до 6");
//          num++;
//          continue;
//      }
//      console.log(num);
//      num++;
//  
//      
//  }

//  let a = +prompt("Введите число");

//  while (true) {
//      if (a > 100) {
//          break;
//      }
//  
//      if (a == 1 || a == 0 || a == -1) {
//          alert("Введите другое число");
//          a = +prompt("Введите число")
//      }
//  
//  
//      a *= a; // a = a * a
//      console.log("Переменная 'a' = ", a);
//  }

//  let num = 100;
//  while (num >= 1) {
//      console.log(num);
//      num--;
//  
//  }

//  let num = 1;
//  while (num <= 100) {
//          if (num % 3 == 0 || num % 5 == 0) {
//              console.log("----");
//          num++;
//          continue;
//      }
//      console.log(num);
//      num++;
//  
//  }


//  let num = +prompt("Введите цифру: ");
//  let numx = 1;
//  while (num <= 9 || numx < 10) {
//      if (num = 1 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 2 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 3 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 4 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 5 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 6 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 7 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 8 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 9 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } else if (num = 10 || numx < 10) {
//          console.log(num * numx);
//          numx++;
//          break;
//      } 
//      console.log();
//      
//  }

//  let a = 1;
//  let num = +prompt();
//  while (a <= 9) {
//      console.log(num, " * ", a, " = ", num * a);
//      a++; 
//  
//  }


//  let randomNumber = Math.floor(Math.random() * 10);
//  let attempCounter = 0;
//  let userNumber = +prompt();
//  while (true) {
//      if (randomNumber == userNumber && attempCounter <= 3) {
//          console.log("Молодец");
//          break;
//      }
//      if (randomNumber == userNumber && attempCounter <= 6) {
//          console.log("Нормально");
//          break;
//      }
//      if (randomNumber == userNumber && attempCounter <= 9) {
//          console.log("Не очень");
//          break;
//      }
//      if (attempCounter >= 10) {
//          console.log("Проиграл");
//          break;
//      }
//      attempCounter++;
//      userNumber = +prompt();
//  }

//  let i = 0;
//  
//  do {
//      console.log(i);
//      i++;
//  } while (i < 0);

//  let i = 0;
//  
//  while (i < 10) {
//      console.log(i);
//      i++;
//  }
//  
//  for (let i = 0; i < 10; i++) {
//      console.log("Цикл for ", i);
//  
//  }

//  for (let i = 0; i < 10; i += 2) {
//      console.log(i);
//  }


//  for (let i = 1; i <= 100; i++) {
//      if (i % 3 === 0 || i % 5 === 0) {
//          console.log(i)
//      }
//  }
//  
//  let num1 = +prompt();
//  for (let a = 1; a <= 9; a++) {
//      console.log(num1, " * ", a, " = ", num1 * a);
//  }


//  let cityName = prompt("Введите название города");
//  
//      //  console.log(cityName[0]);   // Первая буква 
//      //  console.log(cityName[1]);   // Вторая буква
//      //  console.log(cityName[5]);   // Шестая буква
//  
//  for (let i = 0; i < cityName.length; i++) {
//      console.log(cityName[i]);
//  }


//  let userWord = prompt("Введите слово");
//  
//  
//  for (let i = 0; i < userWord.length; i++) {
//      if (userWord[i] === userWord.toUpperCase()) {
//          userWord[i] = userWord[i].toLowerCase();
//          console.log(userWord[i] = userWord[i].toLowerCase());
//      } else {
//          userWord[i] = userWord[i].toUpperCase();
//          console.log(userWord[i] = userWord[i].toUpperCase());
//      }
//  }

//  let userText = prompt();
//  
//  let result = "";
//  let counter = 0;
//  
//  for (let i = 0; i < userText.length; i++ ) {
//      let letter = userText[i]; // каждая буква
//  
//      if (letter.toLowerCase() == 'о') {
//          if (counter <= 5) {
//              counter++;
//              result += 0;
//          } else {
//              result += "O";
//          }
//      } else {
//          result += letter;
//      }
//  }
//  
//  console.log(result);

