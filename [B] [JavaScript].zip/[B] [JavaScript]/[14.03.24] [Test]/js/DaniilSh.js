// 1 

//int = целое число 
//str = строкое число
//arr = массив 
//"word" = слова
//value ?

// 2
//  if ("") {
//      console.log("");
//  } else if ("") {
//      console.log("");
//  } else if ("") {
//      console.log("");
//  } else {
//      console.log("");
//  }

// 3 

//  "+" "-" "*" "**" "/" "//" "%" ("")

// 4 
//  const arr = [];

// 5 (function expression)

// 6 
//  const arr1 = [1,2,3,4,5];
//  for (i = 0; i < arr1.length; i++) {
//      console.log(arr1(i)); 
//  }

//  tets1 = () => {
//      const arr = [];
//  
//  }

// 7 
//  "!="
//  nu1 = 10
//  if (nu1 != 10) {
//      console.log("true");
//  } else {
//      console.log("false");
//  }

// 8 функция которая возращает 1 если число четное и 0 если нечетное 

//  test2 = () => {
//      num2 = +prompt();
//      if (num2 % 2 == 0) {
//          console.log(1);
//      } else if (num2 % 2 != 0) {
//          console.log(0);
//      }
//  }

// 9 DOM [document object model]

// 10 
//  const arr = ["V", "B", "D", "A"];
//  const push = arr.push(1);
//  console.log(push);
//  const pop = arr.pop(2);
//  console.log(pop);
//  const filter = arr.filter();
//  console.log(filter);

// 11 все способы получения элементов по айди
//  const a = document.getElementById

// 12 все методы для управления селектором класс
    

// 13 отличие
// insertHTML  = выполнение работы в html 
// textContent = выполнение работы 


// 14
//  test3 = () => {
//  
//  }

// 15 

// 16 (promise)

// 17 (запрос на сервер)

// 18 (реализовать async)
//  test18 = async () => {
//      const = ;
//      
//  }

// 19 (функция, которая принимает объект со стилям и приминяет их для dom элементов)

// 20
//  event.target - это


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  const fetchData = () => {
//      return new Promise((resolve, reject) => {
//          setTimeout(() => {
//              console.log("Данные получены с сервера");
//              resolve(data);
//          }, 4000);
//      })
//  }
//  
//  fetch
//  console.log(123);
//  
//  fetchData().then((dataFromServer) => {
//      console.log(dataFromServer);
//  })
//  
//  setInterval(() => {
//      console.log("working...");
//  }, 500);
//  
//  
//  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  
//  const arr = [1, 2, 3, 4, 5];
//  
//  arr.push("6");
//  
//  arr.map(function(arrElement, arrElementIndex) {
//      console.log(arrElement);
//      console.log(arrElementIndex);
//  });
//  
//  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const ctx = document.getElementById('myChart');

new Chart(ctx, {
  type: 'radar',
  data: {
    labels: [
      'Eating',
      'Drinking',
      'Sleeping',
      'Designing',
      'Coding',
      'Cycling',
      'Running'
    ],
    datasets: [{
      label: 'Mahmut',
      data: [20, 30, 5, 70, 100, 60, 10],
      fill: true,
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
      borderColor: 'rgb(255, 99, 132)',
      pointBackgroundColor: 'rgb(255, 99, 132)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgb(255, 99, 132)'
    }, {
      label: 'Me',
      data: [60, 70, 50, 60, 50, 30, 60],
      fill: true,
      backgroundColor: 'rgba(54, 162, 235, 0.2)',
      borderColor: 'rgb(54, 162, 235)',
      pointBackgroundColor: 'rgb(54, 162, 235)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgb(54, 162, 235)'
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});


