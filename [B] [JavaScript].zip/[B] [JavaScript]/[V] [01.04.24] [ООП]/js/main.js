//  class Marker {
//      constructor(properties) {
//          this.color = properties.color;
//          this.percentage = properties.percentage;
//      }
//  
//      printText(text) {
//          for (let i = 0; i < text.length; i++) {
//              const char = text.charAt(i);
//              if (char !== ' ') {
//                  if (this.percentage >= 1) {
//                      console.log('%c' + char, 'color: red'); 
//                      this.percentage -= 1;
//                  } else {
//                      console.log('%c' + char, 'color: white'); 
//                  }
//              } else {
//                  if (this.percentage >= 0.5) {
//                      console.log(char);
//                      this.percentage -= 0.5;
//                  } else {
//                      break;
//                  }
//              }
//          }
//      }
//  }
//  
//  class RefillableMarker extends Marker {
//      static MAX_INK_LEVEL = 30;
//  
//      refill() {
//          this.percentage = RefillableMarker.MAX_INK_LEVEL;
//      }
//  }
//  
//  // Пример использования
//  
//  console.log("Заправляемый маркер:");
//  const refillableMarker = new RefillableMarker({ color: "черный", percentage: 50 });
//  refillableMarker.printText("Меня зовут ДаниИл. ДВЕ БУКВЫ И !!!");
//  console.log("Остаток чернил в маркере:", refillableMarker.percentage);
//  
//  console.log("Заправка маркера...");
//  refillableMarker.refill(); 
//  console.log("Остаток чернил в маркере после заправки:", refillableMarker.percentage);
//  
//  console.log("Попытка напечатать текст с новым остатком чернил:");
//  refillableMarker.printText("Хватит меня называть ДАНИЛОМ. Я устал поправлять !");
//  console.log("Остаток чернил в маркере:", refillableMarker.percentage);


//  //_2____________
//  
//  class ExtendedDate extends Date {
//      constructor(properties) {
//          super(properties);
//          this.birthday = '2000-05-12';
//      }
//  
//      getMonthName() {
//          const monthNames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
//          return monthNames[this.getMonth()];
//      }
//  
//      formatDate() {
//          const day = this.getDate();
//          const month = this.getMonthName();
//          return `${day} ${month}`;
//      }
//  
//      isFuture() {
//          const currentDate = new Date();
//          return this.getTime() >= currentDate.getTime();
//      }
//  
//      isLeapYear() {
//          const year = this.getFullYear();
//          return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
//      }
//  
//      getNextDate() {
//          const nextDay = new ExtendedDate(this); 
//          nextDay.setDate(nextDay.getDate() + 1);
//          return nextDay;
//      }
//      
//      isBirthday() {
//          if (!this.birthday) return false;
//          const birthdayDate = new Date(this.birthday);
//          return this.getDate() === birthdayDate.getDate() && this.getMonth() === birthdayDate.getMonth();
//      }
//  
//  }
//  
//  // Пример использования
//  const extendedDate = new ExtendedDate('2024-05-12');
//  
//  console.log("Дата в текстовом формате:", extendedDate.formatDate());
//  console.log("Это будущая дата?", extendedDate.isFuture());
//  console.log("Это високосный год?", extendedDate.isLeapYear());
//  console.log("Следующая дата:", extendedDate.getNextDate().formatDate());
//  console.log("Сегодня мой день рождения?", extendedDate.isBirthday());


//  //_3____________

class Employee {
    constructor(name, position, salary) {
        this.name = name;
        this.position = position;
        this.salary = salary;
    }
}

class EmpTable {
    constructor(employees) {
        this.employees = employees;
    }

    getHtml() {
        let html = '<table border="1">';
        html += '<tr><th>ФИО</th><th>Позиция</th><th>Зарплата</th></tr>';
        this.employees.forEach(employee => {
            html += `<tr><td>${employee.name}</td><td>${employee.position}</td><td>${employee.salary}</td></tr>`;
        });
        html += '</table>';
        return html;
    }
}



//_4____________



class StyledEmpTable extends EmpTable {
    constructor(employees) {
        super(employees);
    }

    getStyles() {
        return `
            <style>
                table {
                    border-collapse: collapse;
                    width: 100%;
                }
                th, td {
                    border: 1px solid black;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
            </style>
        `;
    }

    getHtml() {
        const tableHtml = super.getHtml();
        const styles = this.getStyles(); 
        return `${styles}${tableHtml}`; 
    }
}

const bankEmployees = [
    // Русская Визуальная Новелла "Зайчик" спустя 20 лет...
new Employee('Смирнова Екатерина', 'Гадюка(Бухгалтер)', 2000000),
new Employee('Петров Антон', 'СММ-щик', 40000),
new Employee('Пятифанов Роман', 'Коллектор', 60000),
new Employee('Морозова Полина', 'Сотрудник', 30000),

];

const empTable = new EmpTable(bankEmployees);
const tableHtml = empTable.getHtml();

document.getElementById('employeesTable').innerHTML = tableHtml;



