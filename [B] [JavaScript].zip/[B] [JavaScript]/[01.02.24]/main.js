//  function foo() {
//      let num = 5;
//  
//      return num;
//  }
//  console.log(test3);
//  
//  let test1 = 1;
//  // var test2 = 2;
//  const test3 = 3;
//  
//  console.log(test3);

//  const myFunc = function() {
//      console.log("Function expression");
//  }
//  
//  myFunc();
//  
//  const myArrowFunc = () => {
//      console.log("Arrow function");
//      return "Hello";
//  }
//  
//  myArrowFunc();
//  
//  console.log(myArrowFunc());
//  
//  const testArrow = () => "Hello world!"; 
//  
//  console.log(testArrow());
//  
//  
//  const getSquare = (num) => num * num;
//  
//  console.log(getSquare(5));
//  console.log(getSquare(6));
//  
//  
//  // Любая функция возвращает undefined по умолчанию 
//  // если нет return 
//  
//  const foo1 = () => {
//      console.log("Привет");
//  
//      return undefined;
//  }
//  
//  console.log(foo1());

//__________________________________________________________________________________//

//  const calcSum = function(a, b) {
//      return a + b;
//  }
//  
//  console.log(calcSum(1, 2));

//__________________________________________________________________________________//


//  const arr = [53, 2426, 35, 75];
//  
//  arr.forEach(function(elem, index, arr) {
//      console.log(`${elem} имеет индекс - ${index}`);
//  })
//  
//  const fruits = ["Orange", "Apple", "Banana"];
//  
//  fruits.forEach(function(fruit) { //Для каждого 
//      console.log(fruit);
//  })
//  
//  const result = fruits.every(function(value) {
//      return value.length > 3;
//  }); 
//  console.log(result);
//  
//  const someResult = fruits.some(function(value) {
//      return value == "Apple";
//  });
//  
//  console.log(someResult);
//   
//  const sortedArr = arr.sort(function(a, b) {
//      return a - b;
//  }); // ЭТО СОРТ. СОРТ СОРТ СОРТ СОРТ СОРТ 
//  console.log(sortedArr);
//  
//  const filteredArr = arr.filter(function(num) {
//      return num > 60;
//  });
//  console.log(filteredArr);
//  
//  const numberIndex = arr.indexOf(35);
//  const numberIndex1 = arr.indexOf(5355);
//  console.log(numberIndex);
//  console.log(numberIndex1);
//  
//  const numbers = [1, 2, 64, 356];
//  
//  numbers.push(123)
//  numbers
//  .sort((a, b) => a - b)
//  .filter((value) => value % 2 == 0)
//  .forEach((value) => {
//      console.log(value);
//  };

/*1. Функция принимает 2 массива и возвращает новый массив, в котором собраны все элементы из двух массивов
без повторений.
2. Функция принимает 2 массива и возвращает новый массив,
в котором собраны общие элементы (то есть элементы,
которые встречаются и в первом и во втором массивах)
без повторений.
3. Функция принимает 2 массива и возвращает новый массив, в котором собраны все элементы из первого массива,
которых нет во втором массиве.*/


//  let arr = [];
//  let arr1 = [ 1, 2, 3, 4, 5 ];
//  let arr2 = [ 6, 7, 8, 9, 10];
//  
//  arr.push = (arr1 + arr2);
//  arr.filter;
//  console.log(arr);

//  let arr = [1, 2, 3, 4, 5];
//  let arr1 = [1, 3, 5, 7, 9];
//  
//  const task2 = function(arr, arr1) {
//      arr(i) == arr1(i);
//      console.log(task2);
//  }
//  
//  console.log(task2());

// indexOf - возвращает индекс элемента, если элемент есть в массиве и возвращает -1, если элемента нет в массиве

//  const mergeArrayWithoutDuplicates = function(arr1, arr2) {
//      const result = [];
//      for (let i = 0; i < arr1.length; i++) {
//          if (result.indexOf(arr1[i]) === -1) {
//              result.push(arr1[i]);
//          }
//      }
//  
//      for (let j = 0; j < arr2.length; j++) {
//          if (result.indexOf(arr2[j]) === -1) {
//              result.push(arr2[j]);
//          }
//      }
//  
//      return result;
//  }
//  console.log(mergeArrayWithoutDuplicates([ 1, 2, 3, 4 ],[ 2, 3, 4, 5 ]));

/*Создайте массив строк words и используйте filter, чтобы получить только те строки, которые содержат определенную букву (например, букву "a").

Создайте массив чисел numbers и используйте indexOf, чтобы найти индекс определенного числа в массиве. Если число отсутствует, выведите сообщение.

Создайте строку sentence и используйте split, чтобы разбить ее на массив слов. Затем используйте filter, чтобы получить только те слова, которые начинаются с определенной буквы.

Создайте массив строк fruits и используйте join, чтобы объединить его в одну строку, разделенную запятыми.

Создайте массив чисел randomNumbers и используйте sort, чтобы отсортировать его в порядке убывания.*/

let word = ["Math", "PE", "Geography"];

const filterdWords = word.filter(word => word.includes("a"));


console.log(filterdWords);

let numbers = [1, 2, 3, 4, 5, 6, 7];

const FoundNumbers = numbers.indexOf(numbers =>(i == numbers));

console.log(FoundNumbers);

let massiv = ["Information"];

const RazbitMassiv = function(massiv) {
    const result = [];
    for (let i = 0; i < arr1.length; i++) {
        if (result.split(arr1[i]) === -1) {
            result.push(arr1[i]);
        }
    }
}

