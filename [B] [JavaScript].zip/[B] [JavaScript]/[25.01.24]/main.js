//  let a = 5;
//  console.log(a);
//  
//  a = 53;
//  console.log(a);
//  
//  const b = 10; 
//  console.log(b);
//  
//  b = 11;
//  console.log(b);


//  const arr = [ 1, 2, 3 ];
//  console.log(arr);
//  
//  arr.pop();
//  arr.push(111);
//  
//  console.log(arr);


//  // Объект
//  const person = {
//  //  ключ: значение 
//      firstname: "John",
//      surname: "Smith",
//      age: 20,
//      weight: 60,
//      isMarred: false,
//      skills: ["Html", "Css", "Js"],
//  //  "test test": 123,
//  
//      address: {
//          country: "Kazakhstan",
//          city: "Karaganda",
//          street: "Abdirov",
//      }
//  };

//  console.log(arr[0]);
//  console.log(person['firstname']);
//  console.log(person.firstname);
//  console.log(person['test test']);
//  console.log(person);
//  console.log(person.skills[1]);
//  console.log(person.address.city);
//  
//  for (const key in person) {
//      console.log(person[key]);
//  }

//  person.age = 30;
//  delete(person.weight);
//  for (const key in person) {
//      console.log(key);
//      console.log(person[key]);
//  }
//  //  console.log(person);
//  //  console.log(window);


// const car = {
//     carName: prompt("Введите название машины"),
//     carColor: prompt("Цвет машины"),
//     carPrice: +prompt("Цена машины") + "$",
// 
// };
// car.compl = "Full";
// 
// console.log(car);
// console.log(car.compl);

// 1
//  const task1 = {};
//  
//  task1.name = prompt();
//  task1.price = +prompt();
//  
//  console.log(task1);




//2 

//  let arr = [];
//  
//  let objArr = [];
//  
//  for (let i = 1; i <= 10; i++) {
//  }
//  
//  for (let i = 0; i < arr.length; i++) {
//      let isOdd = arr[i] % 2 == 0;
//      const obj = {
//          digit: arr[i],
//          odd: isOdd,
//      }
//  
//      objArr.push(obj);
//  }
//  
//  console.log(objArr);



//  const arr = [
//      { char: "a", index: 12 },
//      { char: "w", index: 8 },
//      { char: "Y", index: 10 },
//      { char: "p", index: 3 },
//      { char: "p", index: 2 },
//      { char: "N", index: 6 },
//      { char: " ", index: 5 },
//      { char: "y", index: 4 },
//      { char: "r", index: 13 },
//      { char: "H", index: 0 },
//      { char: "e", index: 11 },
//      { char: "a", index: 1 },
//      { char: " ", index: 9 },
//      { char: "!", index: 14 },
//      { char: "e", index: 7 },
//  ];
//  
//  for (let i = 0; i < arr.length; i++) {  // Создаем цикл for для будущей сортировки 
//      for (let j = 0; j < arr.length - 1 - i; j++) { //  Создаем внутри цикла - цикл
//          if (arr[j].index > arr[j + 1].index) { // Условие if создает сортировку для индексов 
//              let temp = arr[j];
//              arr[j] = arr[j + 1];
//              arr[j + 1] = temp;
//          }
//      }
//  }
//  
//  let text = "";
//  for (let i = 0; i < arr.length; i++) {
//      text += arr[i].char;
//  }
//  
//  console.log(text); // После выводит итоговую сортировку 


let arr = [];

for (let i = 1; i <= 10; i++) {
    let randomNum = Math.floor(Math.random() * 100 ); 
    arr.push(randomNum);
    
}
console.log(arr);

const resultObject = {};

let sumArr = 0;
let multiplyArr = 1;

let kratnie = [];
let evenIndexesArr = [];

for (let i = 0; i < arr.length; i++) {
    sumArr += arr[i];
    multiplyArr *= arr[i];

    if (arr[i] % 7 == 0 || arr[8] == 0) {
        kratnie.push(arr[i]);
    }

    if (i % 2 == 0) {
        evenIndexesArr.push(arr[i]);
    }

}
resultObject.sumArr = sumArr;
resultObject.multiplyArr = multiplyArr;
                                                                                                                                                                                                                                                              