const restaurantsURL = "./db/partners.json";

const restaurantsNode = document.querySelector(".restaurants");
const foodMenuNode = document.querySelector(".food-menu");
const backBtn = document.querySelector(".btn");
const foodCart = document.querySelector(".food-cart");

const cart = [];

let foodMenuArr = [];


const getData = async (URL) => {
    const res = await fetch(URL, {
        method: "GET",

    });

    if (res.ok) {
        const data = await res.json();
        return data;
    }

    throw new Error('Ошибка');

}


const createRestaurantsCard = ({ name, kitchen, price, stars, time_of_delivery, image, products }) => {
    //const restaurantsArr = await getData(restaurantsURL);

    const restaurantCard = `
        <div class="restaurant-card" data-product="${products}">
            <h3>${name}</h3>
            <span>${kitchen}</span>
            <ul>
                <li>${price}</li>
                <li>${stars}</li>
                <li>${time_of_delivery}</li>
            </ul>
            <img src="${image}" alt="*">
        </div>
    `;

    restaurantsNode.insertAdjacentHTML("beforeend", restaurantCard);

}

const createFoodCard = ({ name, price, description, image, id }) => {

    const foodCard = `
        <div class="food-card" data-id="${id}">
            <h3 class-name>${name}</h3>
            <span>${price}</span>
            <button class="add-to-cart">Купить</button>
            <p>${description}</p>
            <img src="${image}" alt="">
        </div>
    `;
    restaurantsNode.classList.add("hide");
    backBtn.classList.remove("hide");
    foodMenuNode.classList.remove("hide");
    foodMenuNode.insertAdjacentHTML("beforeend", foodCard);
}


const createFoodCart = () => {
    const cartItems = cart.map(item => `
        <li>
            <span>${item.name} (${item.count})</span>
            <span>${item.price}</span>
            <button class="remove-from-cart" data-id="${item.id}">Remove</button>
        </li>
    `).join('');

    const totalPrice = cart.reduce((total, item) => total + item.price * item.count, 0);

    const foodCartHTML = `
        <div class="cart">
            <h3>Cart</h3>
            <span>Total price: ${totalPrice}</span>
            <ul>${cartItems}</ul>
        </div>
    `;

    foodCart.innerHTML = foodCartHTML;
}





const openRestaurant = async (e) => {
    const target = e.target;
    const restaurant = target.closest(".restaurant-card");

    if (restaurant) {
        const restaurantData = await getData(`./db/${restaurant.dataset.product}`);
        if (restaurantData.length > 0) {
            foodMenuNode.innerHTML = "";
            foodMenuArr = restaurantData;
            restaurantData.map((menuItem) => createFoodCard(menuItem));
        }

    }
}

const toggleMenu = () => {
    restaurantsNode.classList.remove("hide");
    foodMenuNode.classList.add("hide");
    backBtn.classList.add("hide");
}

const addToCart = (e) => {
    const buyBtn = e.target.closest(".add-to-cart");

    if (buyBtn) {
        const foodId = buyBtn.parentElement.dataset.id;
        const foodItem = foodMenuArr.find((food) => food.id === foodId);

        // Check if item is already in cart
        const existingItem = cart.find(item => item.id === foodId);
        if (existingItem) {
            existingItem.count++;
        } else {
            cart.push({
                id: foodItem.id,
                name: foodItem.name,
                price: foodItem.price,
                count: 1,
            });
        }

        createFoodCart();
    }
}

const removeFromCart = (e) => {
    const removeBtn = e.target.closest(".remove-from-cart");

    if (removeBtn) {
        const foodId = removeBtn.dataset.id;
        const index = cart.findIndex(item => item.id === foodId);

        if (index !== -1) {
            if (cart[index].count > 1) {
                cart[index].count--;
            } else {
                cart.splice(index, 1);
            }
        }

        createFoodCart();
    }
}

foodCart.addEventListener("click", removeFromCart);

const init = async () => {
    const restaurantsArr = await getData(restaurantsURL);

    restaurantsArr.map((restaurant) => createRestaurantsCard(restaurant));

}

restaurantsNode.addEventListener("click", openRestaurant);
backBtn.addEventListener("click", toggleMenu);
foodMenuNode.addEventListener("click", addToCart);

init();



fetch('https://jsonplaceholder.typicode.com/posts', {
    method: 'POST',
    body: JSON.stringify(Object.fromEntries(formData)),
    headers: {
        'Content-type': 'application/json; charset=UTF-8',
    },
})
.then(response => {
    if (response.ok) {
        submitButton.style.backgroundColor = 'green';
    } else {
        submitButton.style.backgroundColor = 'red';
    }
    return response.json();
})
.then(data => {
    console.log(data);
    setTimeout(() => {
        submitButton.style.backgroundColor = ''; 
    }, 2000);
})
.catch(error => {
    console.error('Error:', error);
    submitButton.style.backgroundColor = 'red'; 
    setTimeout(() => {
        submitButton.style.backgroundColor = '';
    }, 2000);
});