document.addEventListener("DOMContentLoaded", async () => {
    const signInBlock = document.querySelector(".signin-block");
    const signUpBlock = document.querySelector(".signup-block");

    const toggleSignInBtn = signInBlock.querySelector(".toggle-form");
    const toggleSignUpBtn = signUpBlock.querySelector(".toggle-form");

    const signUpForm = document.querySelector(".signup-form");
    const signInForm = document.querySelector(".signin-form");

    const formsSection = document.querySelector(".authorization");
    const productsSection = document.querySelector(".products");

    const categoriesList = document.querySelector('.categories-list');
    const productsList = document.querySelector('.products-list-ul');

    const container = document.querySelector(".container")

    const sideBar = document.querySelector('.sidebar'); ///использовать для кравсиового сайд бара.

    const pageProdLim = 5;
    let currentPage = 1;
    let skip = (pageProdLim * (currentPage - 1));

    const serverURL = "http://172.28.0.252:9999";

    const register = async (event) => {
        event.preventDefault();

        const form = signUpForm;
        const body = {
            username: form.querySelector('[name="Login"]').value,
            email: form.querySelector('[name="email"]').value,
            password: form.querySelector('[name="password"]').value,
        };

        const response = await fetch(`${serverURL}/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });

        if (response.ok) {
            toggleElems(form, signInForm);
        }
    };

    const userLogin = async (e) => {
        e.preventDefault();

        const userNameInput = signInForm.querySelector('[name="email"]');
        const passwordInput = signInForm.querySelector('[name="password"]');

        const headers = {
            'accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
        }

        const loginData = new URLSearchParams();
        loginData.append("username", userNameInput.value);
        loginData.append("password", passwordInput.value);

        const res = await fetch(`${serverURL}/auth/login`, {
            method: "POST",
            body: loginData,
            headers: headers,
        });

        const data = await res.json();
        if (res.ok) {
            localStorage.setItem("token", data.access_token);
            toggleElems(formsSection, productsSection);
        }
    }

    const authMe = async () => {
        const token = localStorage.getItem("token");

        if (!token) {
            return;
        }

        const res = await fetch(`${serverURL}/auth/me`, {
            method: "GET",
            headers: {
                "Authorization": `Berer ${token}`,
            }
        });

        if (res.status === 401) {
            localStorage.removeItem("token");
            container.classList.remove("hide");
            productsSection.classList.add("hide");
        }
        
        if (res.ok) {
            toggleElems(formsSection, productsSection);
        }
    }

    const getCategories = async () => {
        const res = await fetch(`${serverURL}/products/category`, {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        })

        if (res.ok) {
            const data = await res.json();
            return data;
        }
    }

    const displayCategoriesList = (categories) => {
        const listElement = document.querySelector('.categories-list');
        categories.categories.forEach(({ name, id }) => {
            const listItem = document.createElement('li');
            listItem.dataset.id = id;
            listItem.textContent = name;
            listElement.appendChild(listItem);

        });
    }

    const displaySubcategories = (subcategories) => {


        const list = document.querySelector('.products-list-ul');
        list.innerHTML = '';
        subcategories.forEach(({ name, id }) => {
            const item = document.createElement('li');
            item.dataset.id = id;
            item.textContent = name;
            list.appendChild(item);
        });
        if (!subcategories) {
            const item = document.createElement('li');
            item.textContent = 'Нет подкатегорий';
            list.appendChild(item);
        }
    }

    const toggleElems = (...elems) => {
        elems.forEach(elem => elem.classList.toggle('hide'));
    }

    const pagination = async (arr) => {
        console.log(arr.products.length);
    }


    toggleSignInBtn.addEventListener('click', () => {
        toggleElems(signInForm, signUpForm);
    })


    toggleSignUpBtn.addEventListener('click', () => {
        toggleElems(signInForm, signUpForm);
    })


    categoriesList.addEventListener('click', async (event) => {
        const id = event.target.dataset.id;
        if (id) {
            const res = await fetch(`${serverURL}/products/category/${id}`, {
                method: "GET",
                headers: {
                    "accept": "application/json",
                }
            })
            if (res.ok) {
                const data = await res.json();
                displaySubcategories(data.subcategories)

            }
        }
    })

    const showAllProducts = async (data) => {
        const card = document.querySelector('.card');
        card.innerHTML = '';

        console.log(skip);
        const res = await fetch(`${serverURL}/products/?skip=${skip}&limit=${pageProdLim}&name=${data}`, {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        })
        if (res.ok) {
            card.innerHTML = '';
            const data = await res.json();
            pagination(data);
            data.products.forEach(p => {
                const prodCard = `
                <div class="product-card">
                    <h4>Карточка продукта: ${p.name}</h4>
                    <span>Количество: ${p.count} ШТ</span>
                    <span>images: ${p.images}</span>
                    <span>Цена: ${p.price} ТНГ</span>
                    <span>Описание: <br> ${p.description}</span>
                </div>
                    `
                card.innerHTML += prodCard
            })
        }
    }

    productsList.addEventListener('click', async (event) => {
        const id = event.target.dataset.id;

        const res = await fetch(`${serverURL}/products/category/${id}`, {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        })
        if (res.ok) {
            const data = await res.json();
            //console.log(data.name);
            showAllProducts(data.name)
        }
    })

    signUpForm.addEventListener("submit", register);
    signInForm.addEventListener("submit", userLogin);

    const init = async () => {
        await authMe()
        const categories = await getCategories()
        displayCategoriesList(categories)
    }

    await init();

    const getProducts = async (e, skip = 0) => {
        const target = e.target.closest(".sub-categories").textContent;
    
        if (target) {
            const headers = {
                accept: "application/json",
            };
    
            const res = await fetch(
                `${serverURL}/products/?skip=$(skip)&limit=5category_name=${target}`,
                {
                    method: "GEt",
                    headers: headers,
                }
            );
    
            if (res.ok) {
                const data = await res.json();
                console.log(data);
                insertProductsCard(data.products);
                createPagitation(data.products);
            }
        }
    }

    const createPagitation = async (data) => {
        const productsLength = data.length;
        const buttonsCount = Math.floor()
    
        console.log(data);
        data.forEach(product => {
            const button = document.createElement("button");
            button.textContent = product.name;
            pagitationContainer.append(button);
        })
    };
    
    const openProductsPage = async (e) => {
        const pagitationButton = e.target.closest("button");
    
        if (pagitationButton) {
            currentPage = +pagitationButton.textContent;
        }
    
    }

    function addToBasket(product) {
        const basketItem = document.createElement('div');
        basketItem.classList.add('basket-item');
        basketItem.innerHTML = `
            <p>${product.name} - $${product.price}</p>
        `;
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.classList.add('delete-button');
        deleteButton.addEventListener('click', () => {
            basketItem.remove();
        });
        basketItem.appendChild(deleteButton);
        const basketMain = document.querySelector('.basket-main');
        basketMain.appendChild(basketItem);
    }
    
    function handleProductClick(event) {
        const product = {
            name: event.target.dataset.name,
            price: event.target.dataset.price
        };
        addToBasket(product);
    }
    
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('click', handleProductClick);
    });
    
})








