
document.addEventListener('DOMContentLoaded', () => {

    const authorizacionSection = document.querySelector('.authorizacion');
    const productsSection = document.querySelector('.products');

    const signinForm = document.querySelector('.signin-block');
    const signupForm = document.querySelector('.signup-block');

    const toggleSignInBtn = signinForm.querySelector('.toggle-form');
    const toggleSignUpBtn = signupForm.querySelector('.toggle-form');

    const signUpForm = document.querySelector('.signup-form');

    const categoriesList = document.querySelector('.categories-list');
    const productsList = document.querySelector('.products-list-ul');

    const sideBar = document.querySelector('.sidebar'); ///использовать для кравсиового сайд бара.

    const pageProdLim = 5;
    let currentPage = 1;
    let skip = (pageProdLim * (currentPage - 1));

    const serverURL = 'http://172.28.0.252:9999';

    const register = async (event) => {
        event.preventDefault();

        const form = signupForm;
        const body = {
            username: form.querySelector('[name="Login"]').value,
            email: form.querySelector('[name="email"]').value,
            password: form.querySelector('[name="password"]').value,
        };

        const response = await fetch(`${serverURL}/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });

        if (response.ok) {
            toggleElems(form, signinForm);
        }
    };

    const userLogin = async (event) => {
        event.preventDefault()

        const email = signinForm.querySelector('[name="email"]').value
        const password = signinForm.querySelector('[name="password"]').value

        const headers = {
            'accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
        }

        const sendData = new URLSearchParams();
        sendData.append('username', email);
        sendData.append('password', password);

        const res = await fetch(`${serverURL}/auth/login`, {
            method: 'POST',
            body: sendData,
            headers: headers,
        })

        const data = await res.json();

        if (res.ok) {
            toggleElems(authorizacionSection, productsSection);
            localStorage.setItem('token', data.access_token);
        }

    }

    const checkAuthMe = async () => {
        const token = localStorage.getItem('token');

        if (!token) {
            authorizacionSection.classList.remove('hide');
            return;
        }

        try {
            const response = await fetch(`${serverURL}/auth/me`, {
                headers: { Authorization: `Bearer ${token}` }
            });

            if (response.ok) {
                await response.json();
                toggleElems(authorizacionSection, productsSection);
            }

        } catch (error) {
            localStorage.removeItem('token');
        }
    };

    const getCategories = async () => {
        const res = await fetch(`${serverURL}/products/category`, {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        })

        if (res.ok) {
            const data = await res.json();
            return data;
        }
    }

    const displayCategoriesList = (categories) => {
        const listElement = document.querySelector('.categories-list');
        categories.categories.forEach(({ name, id }) => {
            const listItem = document.createElement('li');
            listItem.dataset.id = id;
            listItem.textContent = name;
            listElement.appendChild(listItem);

        });
    }

    const displaySubcategories = (subcategories) => {


        const list = document.querySelector('.products-list-ul');
        list.innerHTML = '';
        subcategories.forEach(({ name, id }) => {
            const item = document.createElement('li');
            item.dataset.id = id;
            item.textContent = name;
            list.appendChild(item);
        });
        if (!subcategories) {
            const item = document.createElement('li');
            item.textContent = 'Нет подкатегорий';
            list.appendChild(item);
        }
    }


    const showAllProducts = async (data) => {
        const card = document.querySelector('.card');
        card.innerHTML = '';

        console.log(skip);
        const res = await fetch(`${serverURL}/products/?skip=${skip}&limit=${pageProdLim}&name=${data}`, {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        })
        if (res.ok) {
            card.innerHTML = '';
            const data = await res.json();
            pagination(data);
            data.products.forEach(p => {
                const prodCard = `
                <div class="product-card">
                    <h4>Карточка продукта: ${p.name}</h4>
                    <span>Количество: ${p.count} ШТ</span>
                    <span>images: ${p.images}</span>
                    <span>Цена: ${p.price} ТНГ</span>
                    <span>Описание: <br> ${p.description}</span>
                </div>
                    `
                card.innerHTML += prodCard
            })
        }
    }


    const toggleElems = (...elems) => {
        elems.forEach(elem => elem.classList.toggle('hide'));
    }

    const pagination = async (arr) => {
        console.log(arr.products.length);
    }


    toggleSignInBtn.addEventListener('click', () => {
        toggleElems(signinForm, signupForm);
    })


    toggleSignUpBtn.addEventListener('click', () => {
        toggleElems(signinForm, signupForm);
    })


    categoriesList.addEventListener('click', async (event) => {
        const id = event.target.dataset.id;
        if (id) {
            const res = await fetch(`${serverURL}/products/category/${id}`, {
                method: "GET",
                headers: {
                    "accept": "application/json",
                }
            })
            if (res.ok) {
                const data = await res.json();
                displaySubcategories(data.subcategories)

            }
        }
    })


    productsList.addEventListener('click', async (event) => {
        const id = event.target.dataset.id;

        const res = await fetch(`${serverURL}/products/category/${id}`, {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        })
        if (res.ok) {
            const data = await res.json();
            // console.log(data.name);
            showAllProducts(data.name)
        }
    })


    signUpForm.addEventListener('submit', register);
    signinForm.addEventListener('submit', userLogin);

    // sideBar.addEventListener('mouseover', (event) => {
    //     sideBar.style.width = '200px';
    // })

    // sideBar.addEventListener('mouseout', (event) => {
    //     sideBar.style.width = '20px';
    // })



    const initialize = async () => {
        await checkAuthMe()
        const categories = await getCategories()
        displayCategoriesList(categories)
    }



    initialize()
})