const loginBtn = document.getElementById("login-btn");
const emailInput = document.getElementById("email"); // Здесь изменено на "email"
const loginForm = document.querySelector("#login-form");
const registerForm = document.querySelector("#register-form")
const passwordInput = document.getElementById("password");

const registerBtn = document.getElementById("register-btn");
const emailSignup = document.getElementById("email-signup");

const usernameSignup = document.getElementById("username-signup");
const passwordSignup = document.getElementById("password-signup");
const firstnameSignup = document.getElementById("firstname-signup");
const secondnameSignup = document.getElementById("secondname-signup");

const serverURL = "http://172.28.0.96:9999";

const emailBase = document.querySelector(".email-base");
const emailNow = document.querySelector(".email-now");
const nowCompet = document.querySelector(".now-compet");
const OutputBtn = document.getElementById("output-btn")

const emailNews = document.querySelector(".email-news")
const emailWord = document.querySelector(".email-word")
const emailPhoto = document.querySelector(".email-photo")

let isLogined = false; //Украли мой псевдоним :[


// Первая часть сайта
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault(); 

    const email = emailSignup.value;
    const firstname = firstnameSignup.value;
    const secondname = secondnameSignup.value;
    const password = passwordSignup.value;
    const bornDate = "2024-04-01"; 

    try {
        const res = await fetch(serverURL + "/auth/register", {
            method: "POST",
            body: JSON.stringify({
                "email": email,
                "password": password,
                "born_date": bornDate,
                "first_name": firstname,
                "second_name": secondname,

            }),
            headers: {
                'accept': 'application/json',
                "Content-Type": "application/json",
            }
        });

        if (res.ok) {
            console.log("Registration successful!");
        } else {
            console.error("Registration failed.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
});

loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = emailInput.value;
    const password = passwordInput.value;

    try {
        const res = await fetch(serverURL + "/auth/login", {
            method: "POST",
            body: `username=${email}&password=${password}`,
            headers: {
                'accept': 'application/json',
                "Content-Type": "application/x-www-form-urlencoded",
            }
        });

        if (res.ok) {
            console.log("Вход в систему выполнен успешно!");
            checkAuthMe();

            isLogined = true;
            emailNow.classList.add("active");
            emailBase.classList.add("hide");

            emailNews.classList.add("hide");
            emailWord.classList.add("hide");
            emailPhoto.classList.add("hide");

            const data = await res.json();
            localStorage.setItem("token", JSON.stringify(data.accept_token));



        } else {
            console.error("Ошибка входа в систему.");
        }
    } catch (error) {
        console.error("Ошибка:", error);
    }
});

// Вторая часть сайта 
const checkAuthMe = async () => {
    const token = JSON.parse(localStorage.getItem("token"));

    if (!token) {

        return;
    }

    try {
        const res = await fetch(serverURL + "/auth/me", {
            method: "GET",
            header: {
                "accept": "application/json",
                "Authorization": `Bearer ${token}`
            },
        });
        if(res.ok) {
            const data = await res.json();
            console.log(data);
            console.log("Что-то заработало");
        }

    } catch (error) {
        console.log("Что-то не заработало");
    }
}


const competitionBtn = document.getElementById("competition-btn");

competitionBtn.addEventListener("click", async (e) => {
    e.preventDefault();

    try {
        const res = await fetch(serverURL + "/competitions/", {
            method: "GET",
            headers: {
                "accept": "application/json",
            }
        });

        if (res.ok) {
            const dataCompetition = await res.json();
            console.log(dataCompetition);
        } else {
            console.log("Ошибка при получении списка соревнований");
        }

    } catch (error) {
        console.log("Ошибка вывода списка соревнований:", error);
    }
});

const createCompetitionBtn = document.getElementById("createCompetitionBtn");
const competitionList = document.getElementById("competitionList");

async function createCompetition() {

    const isoDateWeight = new Date().toISOString();
    const isoEventDate = new Date().toISOString();

    try {
        const res = await fetch(serverURL + "/competitions/", {
            method: "POST",
            body: JSON.stringify({
                "name": "Даниил",
                "date_weight": isoDateWeight,
                "weighing_location": {
                    "street": "Поинт",
                    "city": "Караганда",
                    "country": "Догадайтесь"
                },
                "event_date": isoEventDate,
                "event_location": {
                    "street": "Поинт",
                    "city": "Караганда",
                    "country": "Догадайтесь"
                },
                "description": "Молодой",
                "category_id": 1 
            }),
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        });

        if (res.ok) {
           
            console.log("Соревнование успешно создано");
        } else {
            console.log("Ошибка при создании соревнования");
        }

    } catch (error) {
        console.log("Ошибка", error);
    }
}


createCompetitionBtn.addEventListener("click", createCompetition);

document.addEventListener("DOMContentLoaded", function() {
    var burgerBtn = document.getElementById('burger-btn');
    var menuLinks = document.getElementById('menu-links');

    burgerBtn.addEventListener('click', function() {
        if (menuLinks.style.display === "block") {
            menuLinks.style.display = "none";
        } else {
            menuLinks.style.display = "block";
        }
    });
});

document.addEventListener("DOMContentLoaded", function() {
    var burgerBtn = document.getElementById('burger-btn');
    var menuLinks = document.getElementById('menu-links');

    burgerBtn.addEventListener('click', function() {
        menuLinks.classList.toggle('show');
    });
});


