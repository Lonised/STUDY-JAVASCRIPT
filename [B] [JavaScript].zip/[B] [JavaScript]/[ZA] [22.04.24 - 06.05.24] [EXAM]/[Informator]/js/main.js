document.getElementById('info-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData(this);


    const submitButton = this.querySelector('button[type="submit"]');
    submitButton.style.backgroundColor = 'orange'; 


    saveFormData(Object.fromEntries(formData));

    fetch('https://jsonplaceholder.typicode.com/posts', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData)),
        headers: {
            'Content-type': 'application/json; charset=UTF-8',
        },
    })
    .then(response => {
        if (response.ok) {
            submitButton.style.backgroundColor = 'green';
        } else {
            submitButton.style.backgroundColor = 'red';
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        setTimeout(() => {
            submitButton.style.backgroundColor = ''; 
        }, 2000);
    })
    .catch(error => {
        console.error('Error:', error);
        submitButton.style.backgroundColor = 'red'; 
        setTimeout(() => {
            submitButton.style.backgroundColor = '';
        }, 2000);
    });
});


function saveFormData(formData) {

    let savedData = JSON.parse(localStorage.getItem('formData')) || [];
    savedData.push(formData);

    localStorage.setItem('formData', JSON.stringify(savedData));
}


