//  const btn = document.querySelector(".btn");
//  const btn1 = document.querySelector(".btn-1");
//  const body = document.body;
//  const btn3 = document.querySelector(".btn-3")
//  
//  let btnPadding = 10;
//  
//  btn3.onclick = () => {
//      console.log("On click btn-4");
//  }
//  
//  btn3.onclick = () => {
//      console.log("Ещё один клик");
//  }
//  
//  
//  
//  /*const myFunc = () => {
//      console.log("Клик!");
//      btn.style.padding = btnPadding + "px";
//      btnPadding += 10;
//      if (btnPadding > 100) {
//          btnPadding = 0;
//      }
//  }*/
//  
//  btn.addEventListener("click", myFunc);
//  
//  btn1.addEventListener("click", (event) => {
//      console.log(event);
//      console.log(event.target);
//      console.log(event.clientX);
//      console.log(event.clientY);
//      console.log(event.ctrlKey);
//      console.log("Клик на кнопку");
//      btn1.style.backgroundColor = "green";
//  });
//  
//  body.addEventListener("keydown", (event) => {
//      console.log(event);
//      console.log(event.code);
//      console.log(event.key);
//      console.log(event.keyCode);
//      if (event.key === "Enter") {
//          console.log("Нажали на Enter");
//          btn.style.backgroundColor = "tomato";
//      }
//  });



//  const likeBtn = document.querySelector(".like-btn")
//  
//  let likeCounter = 0;
//  
//  const likeAnim = [
//      {transform: "scale(1, 1)" },
//      {transform: "scale(0.8, 1.1)" }
//  ];
//  
//  const likeTiming = {
//      duration: 100,
//      iterations: 1,
//  }
//  
//  const increaseLikes = () => {
//      likeCounter++;
//      likeBtn.textContent = "Like" + likeCounter;
//      likeBtn.animate(likeAnim, likeTiming);
//  
//      if(likeCounter >= 10) {
//          likeBtn.removeEventListener("click", increaseLikes);
//      }
//  }
//  
//  likeBtn.addEventListener("click", increaseLikes);
//  
//  likeBtn.addEventListener("click", () => {
//      console.log("Click");
//  });

//  const myForm = document.getElementById("my-form");
//  const inputName = document.getElementById("user-name");
//  const formBtn = document.getElementById("form-btn");
//  
//  myForm.addEventListener("submit", (event) => {
//      event.preventDefault();
//  
//      console.log(event.target);
//      console.log("Submit");
//      console.log(inputName.value);
//  });
//  
//  inputName.addEventListener("input", (event) => {
//      console.log(event.target.value);
//      console.log(inputName.value);
//  });



//  const myForm = document.getElementById("my-form");
//  const inputName = document.getElementById("user-name");
//  const inputSurname = document.getElementById("user-surname")
//  const inputPhone = document.getElementById("user-phone")
//  const formBtn = document.getElementById("form-btn");
//  
//  myForm.addEventListener("submit", (event) => {
//      event.preventDefault();
//  
//      let userNameLength = inputName.value.length;
//  
//      
//      if(userNameLength < 5) {
//          inputName.style.backgroundColor = "tomato";
//          setTimeout(() => {
//              inputName.style.backgroundColor = " ";
//          }, 3000);
//      } else {
//          inputName.style.backgroundColor = " ";
//      }
//  
//  
//      if (userPhoneValue.length < 12 || userPhoneValue.slice(0, 2) != "+7") {
//          console.log(userPhoneValue.slice(0, 2));
//          console.log(userPhoneValue.length);
//          inputPhone.style.border = "2px solid tomato";
//      } else {
//          inputPhone.style.border = "";
//      }
//  
//      
//  });


const box = document.querySelector(".box");
const water = document.querySelector(".water");

const myFunc = () => {
    water.style.padding = waterPaddingBottom + "px";
    waterPaddingBottom += 10;
}


