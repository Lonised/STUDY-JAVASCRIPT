//  const textInput = document.querySelector("#my-input");
//  const sendBtn = document.querySelector("#send");
//  
//  const serverURL = "wss://socketsbay.com/wss/v2/1/demo/";
//  
//  const socket = new WebSocket(serverURL);
//  
//  socket.addEventListener("open", () => {
//      console.log("Connected to:", socket.url);
//  });
//  
//  socket.addEventListener("message", (event) => {
//      console.log("New message:", event.data);
//  });
//  
//  socket.addEventListener("close", () => {
//      console.log("Socket closed!");
//  });
//  
//  socket.addEventListener("error", () => {
//      console.log("Something going wrong :<");
//  });
//  
//  sendBtn.addEventListener("click", () => {
//      const inputText = textInput.value
//      socket.send(inputText);
//      textInput.value = '';
//  });

const loginBtn = document.getElementById("login-btn");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");

const registerBtn = document.getElementById("register-btn");
const emailSignup = document.getElementById("email-signup");
const usernameSignup = document.getElementById("username-signup")
const passwordSignup = document.getElementById("password-signup");

const serverURL = "http://172.28.0.230:5000";

registerBtn.addEventListener("click", async (e) => {
    e.preventDefault();

    const registerUser = async () => {

        const registerData = {
            "email": emailSignup.value,
            "password": passwordSignup.value,
            "username": usernameSignup.value,
        }


        const res = await fetch(`${serverURL}/auth/register`, {
            method: "POST",
            body: JSON.stringify(registerData),
            headers: {
                'accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })

        const data = await res.json();
        console.log(data);
    }

    registerUser();



})


loginBtn.addEventListener("click", async (e) => {
    e.preventDefault();
    
    const loginUser = async () => {
        const res = await fetch(`${serverURL}/auth/login`, {
            method: "POST",
            body: `grant_type=&username=${usernameInput.value}&password=${passwordInput.value}`,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })

        const data = await res.json();
        console.log(data);
        if (res.ok) {
            const data = await res.json();
            console.log(data);
            localStorage.setItem("token", data.access_token);
        }

    }

    loginUser();
});




const checkAuth = async () => {
    const token = localStorage.getItem("token");

    const res = await fetch(`${serverURL}/auth/me`, {
        headers: {
            "Authorization": `Bearer ${token}`
        },
        mode: "no-cors"
    });

    if (res.ok) {
        console.log(await res.json());
    }
}

checkAuth();