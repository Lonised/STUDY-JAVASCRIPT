const text = "Hello World, 123 457 89 999";

//Регулярные выражения 
// \d - digit - число
// \d+ - все подходящие числа (но только одно совпадение)

//Флаг g - global: Найти все совпадения в строке 
//  const pattern = /\d+/g;
//  //  const groupPattern = /\d{3}/;
//  
//  
//  const str = "qweqwe 77777 444"
//  // Ищем 2 группы по 3 111 222
//  // Пробелы играют значение 
//  const groupPattern = /(\d{5}) (\d{3})/;
//  
//  const result = str.match(groupPattern);
//  
//  //  console.log(text.replace("World", "Peace")); //replace - заменяет 
//  //  console.log(text.replace(pattern, "987"));
//  
//  // Выведет true, если нашли совпадение в строке  
//  //  console.log(pattern.test(text));
//  
//  console.log(result);
//  console.log(result[0]);
//  console.log(result[1]);
//  console.log(result[2]);
//  
//  // i - ignore не учитываем регистр 
//  const wordPattern = /example/g;
//  
//  const text1 = "hello this is my example. First example";
//  
//  const rezult1 = text1.replace(wordPattern, "пример")
//  
//  console.log(rezult1);

//////////////////////////////////////

// DD/MM/YYYY
// \b{1,2} - идет либо одно, либо два числа
// \/ означает что в строке дальше должен быть символ "/"
//  const dateRegex = /\b\d{1,2}\/\d{1,2}\/\d{4}/;
//  const test = '12/05/2000';
//  
//  console.log(test.match(dateRegex));
//  
//  const phoneRegex = /^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\-]?)?[\d\- ]{7,10}$/;
//  
//  const userPhone = "87771231223";
//  console.log(userPhone.match(phoneRegex));


////////// Попытка использовать файл 


//  const uploadInp = document.querySelector("#pdf-file");
//  
//  uploadInp.addEventListener("change", (e) => {
//      const file = e.target.files[0];
//  
//      if (file.type !== "application/pdf") {
//          console.log("Неверный формат файла");
//          return;
//      }
//      
//      const fileReader = new FileReader();
//  })

function displayText() {
    const inputText = document.getElementById("textInput").value;
    document.getElementById("output").innerHTML = inputText;

    localStorage.setItem('outputText', inputText);
}

function processText() {
    const inputText = document.getElementById("textInput").value;

    const processedText = inputText.replace(/\*\*\*(.*?)\*\*\*/g, '<h1>$1</h1>')
                                    .replace(/\>\>\>(.*?)\>\>\>/g, '<b>$1</b>')
                                    .replace(/\-\-\-(.*?)\-\-\-/g, '<a href="#">$1</a>')
                                    .replace(/\=\=\=(.*?)\=\=\=/g, '<p>$1</p>')
                                    .replace(/(^|\n)- (.*)/g, '<li>$2</li>'); // Обработка списков

    document.getElementById("output").innerHTML = processedText;

    localStorage.setItem('processedText', processedText);
}

function addStars() {
    var textarea = document.getElementById('textInput');
    textarea.value += '***';
}

function addRight() {
    var textarea = document.getElementById('textInput');
    textarea.value += '>>>';
}

function addMinus() {
    var textarea = document.getElementById('textInput');
    textarea.value += '---';
}

function addFinish() {
    var textarea = document.getElementById('textInput');
    textarea.value += '===';
}
function addList() {
    var textarea = document.getElementById('textInput');
    textarea.value += '- ';
}

window.onload = function() {
    const outputText = localStorage.getItem('outputText');

    if (outputText) {
        document.getElementById("output").innerHTML = outputText;
    }

    if (processedText) {
        document.getElementById("output").innerHTML = processedText;
    }
};
function clearOutput() {
    document.getElementById("output").innerHTML = "";
    localStorage.removeItem('outputText'); 
}
