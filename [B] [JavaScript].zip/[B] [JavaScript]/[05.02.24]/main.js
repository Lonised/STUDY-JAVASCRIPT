//  const arr = [254, 4257, 24675, 8764, 45];
//  
//  const resultArr = arr.map(function(value) {
//      if (value % 2 ==0) {
//          return Math.floor(value * 2);
//      } 
//      return Math.floor(value / 2);
//  });

//  console.log(resultArr);

//  const resultSum = 0;
//  
//  for (let i = 0; i < resultArr.length; i++) {
//      resultSum += resultArr[i]
//  }
//  
//  console.log(resultSum);

//  let resultSum = resultArr.reduce(function(prevValue, acc) {
//      console.log(prevValue);
//      console.log(acc);
//      console.log(`prev ${prevValue}, acc ${acc} - prev + acc ${prevValue + acc}`);
//  
//      return prevValue + acc;
//  })
//  console.log(resultSum);
//  
//  const fruitsArr = ["Banana", "Orange", "Mango"];
//  
//  let concatArrFruits = fruitsArr.reduce(function(prev, acc) {
//      console.log(prev + acc);
//      return prev + acc;
//  })
//  console.log(concatArrFruits);

// !
//  const getFactorial = (num) => {
//      let result = 1;
//      for (let i = 1; i < num; i++) {
//          result *= i;
//      }
//      console.log(result);
//  }
//  
//  getFactorial(5);


//  const getFactorial = (num) => {
//      if (num === 1 || num === 0) {
//          return 1;
//      } else {
//          debugger //Полезная команда
//          return num * getFactorial(num - 1);
//      }
//  }
//  
//  let result = getFactorial(5);
//  console.log(result);
//  //Вызов функции внутри себя - Рекурсия.


//  const arr = [254, 4257, 24675, 8764, 45];
//  //  
//  //  // index = 0 в параметрах функции, указывает, что значение по умолчанию = 0. Если при вызове функции не передать значение, то возьмется это значение.
//  const getArrSum = function(arr, index = 0) {
//      if (index === arr.length - 1) {
//          return arr[index];
//      } else {
//          return arr[index] + getArrSum(arr, index + 1);
//      }
//  }
//  
//  let sum = getArrSum(arr);
//  console.log(sum);

// Строки являются псевдомассивом 
//  let str = "Hello World";
//  console.log(str.substring(0, 5));

//      let psevdoMassiv = {
//          0: "H",
//          1: "e",
//          2: "l",
//      };
//      psevdoMassiv[0] 
//      console.log(str.substring(0, 5));


//  let str = "Hello World";
//  console.log(str.substring(0, 5));
//  console.log(str.substring(1));
//  console.log(str.substring(2));




// 1
//  let str = "Hello World";
//  
//  const reverseString = function(str) {
//      if (str === "") return "";
//  
//      return reverseString(str.substring(1)) + str[0];
//  }
//  
//  console.log(reverseString(str));


//  const obj = {
//      data: {
//          subObj: {
//              subData: {
//                  test: {
//                      result: "Success"
//                  },
//                  subSubObj: {
//                      str: "Hello"
//                  }
//              }
//          },
//      },
//  };
//  
//  console.log(obj);
//  for (const key in obj) {
//      console.log(obj[key]);
//      console.log(typeof(obj[key]));
//  }

//2


//  const result = function(obj) {
//      if (obj === "") 
//      return result;
//  }
//  
//  let task2 = 


//  const getDataFromObject = (obj) => {
//      for (const key in obj) {
//          if (typeof(obj[key]) === "object") {
//              return getDataFromObject(obj[key]);
//          }
//          return obj[key];
//      }
//  }
//  
//  console.log(getDataFromObject(obj));


//  function Skobki(num) {
//      if (num == 0) {
//          return null;
//      } 
//          return '(' * Skobki(num - 1) + Skobki(num - 1) * ')'
//      }
//  }
//  
//  let a = Skobki(4);
//  console.log(a);

//  const isOdd = (number) => {
//      if (number % 2 == 0) {
//          return true;
//      }
//      return false;
//  }

//  const isOdd = (number) => {
//      number % 2 == 0 ? true : false;
//  }
//  
//  const doSomth = (number) => {
//      let result = isOdd(number) ? number * 10 : number - 10;
//      console.log(result);
//      return result;
//  }
//  doSomth(8);
//  doSomth(7);

// // Вопросительный знак - Тернарный оператор


//  let str = "Hello world";
//  console.log(str.slice(0, 5));
//  console.log(str.slice(-5, -1));

let date = Date.now();
console.log(date);
console.log(new Date);
console.log(Date.parse("01.01.2024"));
console.log(new Date("01.01.2024").getDay());
console.log(new Date("01.01.2024").getDate());
console.log(new Date("01.01.2024").getFullYear());
console.log(new Date("01.01.2024").getHours());
console.log(new Date("01.01.2024").getTime());
console.log(new Date("01.01.2024").getSeconds());


setTimeout(function() {
    console.log("Sleep..");
}, 1000);

setTimeout(() => {
    console.log("TIME");
}, 3000);

const sayHi = () => {
    console.log("Hi");
}

setTimeout(sayHi, 1500);

let myInterval = setInterval(sayHi, 500);

setTimeout(() => {
    clearInterval(myInterval);
    console.log("Перестань");
}, 5000);

console.log("Сам перестань");