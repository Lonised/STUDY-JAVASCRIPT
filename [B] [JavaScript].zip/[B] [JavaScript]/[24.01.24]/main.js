//  let myMarks = [ 12, 7, 6, 10, 40 ];
//  
//  console.log(myMarks);
//  console.log(myMarks[1]);
//  console.log(myMarks[0]);
//  
//  // Массив == Array
//  // arr.leigth = длина массива
//  console.log(myMarks.length);
//  
//  // -1 = Крайний индекс в массиве
//  console.log(myMarks.length - 1);
//  
//  // Цикл позволяет перечислить все элементы в массиве 
//  for (let i = 0; i < myMarks.length; i++) {
//      console.log(myMarks[i]);
//  }


//  let booksForRead = [ "Book1", "Book2", "Book3" ];
//  let boolArr = [ true, true, true, true, false ];
//  
//  console.log(booksForRead);
//  
//  let matrix = [ [1, 2, 3], [4, 5, 6], [7, 8, 9] ];
//  
//  console.log(matrix);
//  console.log(matrix[0][1]); // 2


//  let fruitsArr = [ "Apple", "Orange", "Kiwi" ];
//  console.log(fruitsArr);
//  
//  let newFruit = prompt("Введите фрукт ");
//  
//  fruitsArr.push("Banana");
//  fruitsArr.push(newFruit);
//  fruitsArr.push("Test");
//  
//  console.log(fruitsArr); // Метод push = добавляет в конец массива новое значение
//  
//  fruitsArr.pop(); // Метод pop = удаляет с массива последнее значение
//  
//  console.log(fruitsArr);
//  
//  fruitsArr.shift(); // Удаляет первый элемент
//  fruitsArr.unshift("Mandarin"); // Добавляет новый элемент в начало
//  
//  console.log(fruitsArr);


// 0.1 

//  let numberArr = [];
//  
//  for (let i = 0; i < 10; i++) {
//      let num = +prompt();
//  
//      if (!isNaN(num)) {
//  
//          numberArr.push(task);
//  
//      } else {
//  
//          alert("Ошибка")
//      }
//  
//  }
//  console.log(numberArr)

// 1. Заполните массив от 1 до 1000
// 2. Найдите сумму всех чисел этого массива
// 3. Найдите сумму всех четных чисел этого массива
// 4. Пользватель вводит имена в массив, вам нужно
// все имена записать с большой буквы 
// (даже если ввели с маленькой)
// 5.  Заполнить массив 10 числами. Вычислить сумму 
// элементов массива, имеющие нечетный индекс
// 6. Создать массив символов, вывести символы так,
// чтобы получилось ваше имя


// 1

//  let task1 = [];
//  
//  for (let i = 0; i < 1000; i++) {
//      task1.push(i);
//  }
//  console.log(task1);
//  
//  // 2
//  
//  let sum = 0;
//  
//  for (let i = 0; i < task1.length; i++) {
//      sum += task1[i]
//      //sum = sum + task1[i]
//  
//  }
//  console.log(sum);
//  
//  // 3
//  let sumEven = 0;
//  
//  for (let i = 0; i < task1.length; i++) {
//      let isEven = task1[i] % 2 == 0;
//      if (isEven) {
//          sumEven += task1[i]
//      }
//  }
//  console.log(sumEven);

// 4  ? 

//  let namesArr = [];
//  
//  for (let i = 0; i < 2; i++) {
//      let humanName = prompt();
//      namesArr.push(humanName.replace(
//          humanName[0], humanName[0].toUpperCase()
//      ));
//  }
//  console.log(namesArr);




//      if (!isUpper) {
//          temp += humanName[0].toUpperCase();
//      } else {
//          temp += humanName[0];
//      }
//  
//      for (let j = 1; j < humanName.length; j++) {
//          
//          temp += humanName[j];
//      }
//  
//      namesArr.push(temp);
//      
//  }
//  namesArr.push(humanName);


// 5 

//  let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
//  let sum = 0;
//  
//  for (let i = 0; i < arr.length; i++) {
//      if (i % 2 != 0) {
//          sum += arr[i];
//          
//      }
//  }
//  console.log("Сумма нечетных индексов = ", sum)


// 6

//  console.log(typeof([1, 2, 3])); // object 
//  
//  let num1 = 5;
//  let num2 = "qwe";
//  let num3 = true;
//  
//  let arr = []; // object
//  
//  let variable; // Переменная
//  console.log(typeof(variable));
//  
//  let nothing = null; // object нет значения
//  
//  let sym = Symbol("*");
//  console.log(sym);

// number
// string
// bool
// undefined
// object
// Symbol

//
//  let arr = [ 5, 3, 7, 1 ];
//  //  let temp = arr[0];
//  //  arr[0] = arr[1];
//  //  arr[1] = temp;
//  
//  for (let i = 0; i < arr.length; i++) {
//  
//      for (let j = 0; j < arr.length - 1; j++) {
//  
//          // Ворой цикл, для сравнения каждого элемента со всеми остальными
//          
//          if(arr[i] > arr[j + 1]) {
//              let temp = arr[i];
//              arr[i] = arr[j + 1];
//              arr[j + 1] = temp;
//          }
//  
//      } 
//  
//  }
//  
//  console.log(arr)

/*
    Пройтись по массиву
    Во втором цикле проверяем каждый элемент со следующим
    Если элемент справа больше чем элемент слева
    То меняем их местами
    Если нашли такой элемент, начинаем по новой
*/