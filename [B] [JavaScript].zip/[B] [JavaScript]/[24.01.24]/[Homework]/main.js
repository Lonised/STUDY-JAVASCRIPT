
// Итак...

// Сортировка вставками. 

// Один из самых эффективных алгоритмов для небольших списков 

// Один из самых понятных для меня (Я только его более-менее понял...)

// Элементы вставляются по одному в уже отсортированную часть массива

// Короче, нажмите ctrl + s и запустите в браузере. Так вы легче ...
// ... поймете суть данного алгоритма 



let input = prompt("Введите числа через пробел: ");
let arrayToSort = input.split(' ').map(Number); 

console.log("Исходный массив:", arrayToSort);

let n = arrayToSort.length;

for (let i = 0; i < n - 1; i++) {
    let minIndex = i;

    // Находим индекс минимального элемента в оставшейся части массива
    for (let j = i + 1; j < n; j++) {
        if (arrayToSort[j] < arrayToSort[minIndex]) {
            minIndex = j;
        }
    }

    // Обмен значениями минимального элемента и текущего элемента
    if (minIndex !== i) {
        let temp = arrayToSort[i];
        arrayToSort[i] = arrayToSort[minIndex];
        arrayToSort[minIndex] = temp;
    }
}

console.log("Отсортированный массив:", arrayToSort);

