//  BOM - Browser Object Module
//  DOM - Document Object Module

//  console.log(window); 
//  Выводит настройки виндов

//  console.log(window.location);
//  // Выводит локацию виндов
//  console.log(window.history);
//  // Выводит историю
//  console.log(window.navigator);
//  Большой объект. Здесь есть кодовое имя, версия, включены ли всякие настройки и т.д.

//  console.log(window.navigator);
//  
//  const userAgent = window.navigator.userAgent;
//  console.log(userAgent);
//  if (userAgent.includes("Chrome")) {
//      console.log("Используется браузер Хром");
//  } else if (userAgent.includes("Firefox")) {
//      console.log("Используется мозилла");
//  } else {
//      console.log("Другой браузер");
//  }
//  
//  //С помощью условия мы определяем, какой используетсяс браузер
//  
//  const userLanguage = window.navigator.language;
//  console.log(userLanguage);
//  // Какой используется язык в браузере по дефолту 
//  
//  const userEthernetStatus = window.navigator.onLine;
//  console.log("________");
//  console.log(userEthernetStatus);
//  console.log("________");
//  
//  if (userEthernetStatus) {
//      console.log("Интернет есть");
//  } else {
//      console.log("Интернета нет");
//  }
//  console.log("________");
//  
//  // Используется ли браузер сейчас или нет. Этот код определит (True)
//  
//  const userPlatform = window.navigator.platform;
//  console.log(userPlatform);
//  
//  // Какая используется платформа. Вин32 или Вин64 или Мак
//  // (Это свойство убрали из главных)
//  
//  const cookieStatus = window.navigator.cookieEnabled;
//  console.log(cookieStatus);
//  console.log("________");
//  
//  // Используется ли куки статус
//  
//  const userLocation = window.navigator.geolocation.getCurrentPosition((coord) => {
//      console.log(coord.coords.latitude);
//      console.log(coord.coords.longitude);
//  });
//  console.log(userLocation);
//  console.log("________");
//  
//  // Данная команда выводит наше местоположение. ГЕтКарет - это разрешение на доступ к геолокации


//  const box = document.querySelector(".box");
//  const counterSpan = document.querySelector(".counter");
//  const miniBox = document.querySelector(".mini-box")
//  
//  
//  console.log(box);
//  
//  let counter = 1;
//  
//  box.addEventListener("click", () => {
//      box.classList.toggle("toggled");
//  
//      console.log(box.classList.contains("test"));
//      console.log(box.classList.contains("box"));
//  
//      counterSpan.textContent = counter;
//  
//      const smallbox = document.createElement("div");
//      smallbox.classList.add("mini-box");
//      box.append(smallbox);
//  
//      counter ++;
//  
//      if (event.target.classList.contains("mini-box")) {
//          event.target.style.borderRadius = "50%";
//      }
//      // таргет - элемент, на который мы кликнули
//  
//  
//  
//  
//  });


//Создаем новый конст - обращаемся к документу - добавляем минибокс, как новый див (квадрат) - добавляет внтри квадрата при нажатии клавиши мыши
//Далее, при клике мыши меняется цвет большого квадрата 
//Далее, мы проверяем с помощью контеинс (фалс тру - фалс тру - фалс тру) при клике мыши
//Далее, если кликнуть на маленький квадрат - превращается в круг 




// СОЗДАЕМ КРЕСТИКИ - НОЛИКИ, ЕПТА
// В АД БЕЗ ОЧЕРЕДИ ПОПАДУ 
// ЗА ТАКОЕ ПРЕМИЮ ДОЛЖНЫ ВЫДАТЬ


const area = document.querySelector(".area");

const board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', ''],
];

let zeroMove = true;

function displayBoard() {
    area.innerHTML = '';
    board.forEach((row, i) => {
        row.forEach((cell, j) => {
            const ceil = document.createElement('div');
            ceil.classList.add('ceil');
            ceil.dataset.row = i;
            ceil.dataset.col = j;
            ceil.textContent = cell;
            area.appendChild(ceil);
        });
    });
}

function checkWinner() {
    for (let i = 0; i < 3; i++) {
        if (board[i][0] !== '' && board[i][0] === board[i][1] && board[i][0] === board[i][2]) {
            return board[i][0];
        }
        if (board[0][i] !== '' && board[0][i] === board[1][i] && board[0][i] === board[2][i]) {
            return board[0][i];
        }
    }
    if (board[0][0] !== '' && board[0][0] === board[1][1] && board[0][0] === board[2][2]) {
        return board[0][0];
    }
    if (board[0][2] !== '' && board[0][2] === board[1][1] && board[0][2] === board[2][0]) {
        return board[0][2];
    }
    if (!board.flat().includes('')) {
        return 'draw';
    }
    return null;
}

function playerMove(event) {
    const target = event.target;
    if (target.classList.contains('ceil') && target.textContent === '') {
        const row = parseInt(target.dataset.row);
        const col = parseInt(target.dataset.col);
        if (zeroMove) {
            board[row][col] = 'O';
            target.classList.add("zero");
            target.textContent = "O";
        } else {
            board[row][col] = 'X';
            target.classList.add("mark");
            target.textContent = "X";
        }
        const winner = checkWinner();
        if (winner) {
            if (winner === 'draw') {
                alert("Ничья!");
            } else {
                alert(`Победили ${winner === 'O' ? 'нолики' : 'крестики'}!`);
            }
            board.forEach(row => row.fill(''));
            displayBoard();
        } else {
            zeroMove = !zeroMove;
        }
    }
}

function play() {
    displayBoard();
}

area.addEventListener("click", playerMove);

play();



//  const area = document.querySelector(".area");
//  
//  const board = [
//      ['', '', ''],
//      ['', '', ''],
//      ['', '', ''],
//  ];
//  
//  let zeroMove = true;
//  
//  function fillBoard() {
//      for (let i = 0; i < board.length; i++) {
//          console.log("Строки доски:", board[i]);
//          for (let j = 0; j < board[i].lenght; j++) {
//              console.log("Ячейка: ", board[i][j]);
//          }
//      }
//  }
//  
//  function playerMove(event) {
//      const currentCeil = event.target; //Та клетка, которую мы нажали 
//  
//      const ceilsArr = Array.from(currentCeil.parentElement.children);
//      console.log(ceilsArr);
//  
//      if (zeroMove) {
//          currentCeil.textContent = "O";
//          currentCeil.classList.add("zero");
//          zeroMove = false;
//      } else {
//          currentCeil.textContent = "X";
//          currentCeil.classList.add("mark");
//          zeroMove = true;
//      }
//  }
//  
//  
//  
//  area.addEventListener("click", playerMove);