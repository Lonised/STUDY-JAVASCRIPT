//____________________ПРИМЕР ДЛЯ ПРАКТИКИ_____________________________________________

//  const addBtn = document.querySelector("#add");
//  const cont = document.querySelector(".test");
//  
//  const allLinksQuery = document.querySelectorAll("a");
//  const allLinksGetElement = document.getElementsByTagName("a");
//  
//  addBtn.addEventListener("click", () => {
//      const newElem = document.createElement("a");
//      newElem.textContent = "Hello";
//  
//      cont.append(newElem);
//  
//      console.log(allLinksQuery);
//      console.log(allLinksGetElement);
//  });


//_________________________________________________________________

const tasksList = document.querySelector(".todos");
const createTaskBtn = document.querySelector(".add-btn");
const taskTitleInput = document.querySelector(".add-inp");

const taskTitleEnter = document.querySelector(".add-inp");
let tasksListArr = JSON.parse(localStorage.getItem("Tasks")) || [];

const insertTask = (newElem) => {
    tasksList.insertAdjacentHTML("afterbegin", newElem);
}


const createTask = () => {
    const taskTitle = taskTitleInput.value;
    if (taskTitle.length < 3) {
        alert("Минимальное значение!");
        return;
    }

    const newElem = `
        <li>
            <span>${taskTitle}</span>
            <button class="delete-btn">X</button>
        </li>
    `;

    tasksListArr.push({
        title: taskTitle
    });

    localStorage.setItem("Tasks", JSON.stringify(tasksListArr));
    insertTask(newElem);
}
const deleteTask = (event) => {
    const target = event.target;
    const deleteBtn = target.closest(".delete-btn");
    if (deleteBtn) {
        const taskIndex = Array.from(tasksList.children).reverse().indexOf(deleteBtn.parentElement);
        // Удаляем элемент по его индексу
        tasksListArr.splice(taskIndex, 1);  
        localStorage.setItem("Tasks", JSON.stringify(tasksListArr));

        deleteBtn.parentElement.remove();
    }

    updateTaskCount();
};
const toggleTaskDone = (event) => {
    const target = event.target;
    if (target.tagName === 'LI') {
        target.classList.toggle('done');
        const taskIndex = tasksListArr.indexOf(target.outerHTML);
        if (taskIndex !== -1) {
            tasksListArr[taskIndex] = target.outerHTML;
            localStorage.setItem("Tasks", JSON.stringify(tasksListArr));
        }
    }

}
tasksList.addEventListener("click", toggleTaskDone);
const init = () => {
    const tasksFromLocalStorage = JSON.parse(localStorage.getItem("Tasks"));
    if (tasksFromLocalStorage && tasksFromLocalStorage.length > 0) {
        tasksListArr = tasksFromLocalStorage;
        tasksListArr.map((task) => insertTask(task));
    }

    updateTaskCount();

    const deleteAllBtn = document.querySelector(".delete-all-btn");
    deleteAllBtn.addEventListener("click", deleteAllTasks);
};
const updateTaskCount = () => {
    const countElement = document.querySelector(".count");
    countElement.textContent = tasksListArr.length;

    
};
const deleteAllTasks = () => {
    tasksListArr.length = 0;
    localStorage.removeItem("Tasks");
    tasksList.innerHTML = ""; 
    updateTaskCount();
};
taskTitleEnter.addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        createTask();
    }
});
createTaskBtn.addEventListener("click", createTask);
tasksList.addEventListener("click", deleteTask);

//Когда DOM дерево прогрузится у пользователя, сработает это событие.
window.addEventListener("DOMContentLoaded", init);



