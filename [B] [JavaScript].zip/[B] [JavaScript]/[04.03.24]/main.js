//  const wait = (sec) => {
//      return new Promise ((resolve, rejects) => {
//          setTimeout(() => {
//              resolve("Hello");
//          }, sec);
//      })
//  }
//  
//  const showMessage = async () => {
//      console.log("Start");
//  
//      const message = await wait(2000);
//      const message1 = await wait(1000);
//      const message2 = await wait(3000);
//  
//      console.log(message);
//      console.log(message1);
//      console.log(message2);
//  
//      console.log("End");
//  }
//  
//  console.log(1);
//  showMessage();
//  console.log(2);


//  //--------------------------------------------------------------------------
//  
//  const getData = async () => {
//      const res = await fetch("https://jsonplaceholder.typicode.com/todos");
//  
//      console.log(res);
//      if (res.ok) {
//          const data = await res.json();
//          console.log(data);
//  
//          return data;
//      }
//  
//      console.error("Ошибка!");
//  }
//  
//  const init = async () => {
//      const dataFromServer = await getData();
//      console.log(dataFromServer);
//  }
//  
//  //--------------------------------------------------------------------------


document.addEventListener('DOMContentLoaded', function() {
    const display = document.querySelector('.calc-print p');
    const buttons = document.querySelectorAll('.calc-input button');

    let currentInput = '';
    let firstOperand = null;
    let operator = null;

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const buttonText = button.textContent;

            if (buttonText === 'C') {
                clear();
            } else if (buttonText === '=') {
                calculate();
            } else if (buttonText === '+' || buttonText === '-' || buttonText === '*' || buttonText === '/') {
                handleOperator(buttonText);
            } else {
                currentInput += buttonText;
                updateDisplay();
            }
        });
    });

    function updateDisplay() {
        display.textContent = currentInput;
    }

    function clear() {
        currentInput = '';
        firstOperand = null;
        operator = null;
        updateDisplay();
    }

    function handleOperator(nextOperator) {
        const inputValue = parseFloat(currentInput);

        if (firstOperand === null) {
            firstOperand = inputValue;
        } else if (operator) {
            const result = operate(firstOperand, inputValue, operator);
            currentInput = String(result);
            firstOperand = result;
        }

        currentInput = '';
        operator = nextOperator;
        updateDisplay();
    }

    function calculate() {
        const inputValue = parseFloat(currentInput);

        if (operator) {
            const result = operate(firstOperand, inputValue, operator);
            currentInput = String(result);
            firstOperand = null;
            operator = null;
            updateDisplay();
        }
    }

    function operate(a, b, op) {
        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                return a / b;
            default:
                return null;
        }
    }
});
