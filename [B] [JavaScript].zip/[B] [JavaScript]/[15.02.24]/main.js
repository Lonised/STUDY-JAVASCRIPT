const adminPanel =  document.querySelector(".admin-panel");
const price = document.querySelector(".price");

const addBtn = document.querySelector("#btn");
const cardsContainer = document.querySelector(".cards")

const titleInp = document.querySelector("#title-inp");
const priceInp = document.querySelector("#price-inp");
const countRange = document.querySelector("#count-range");






//Отображение числа, где стоит ползунок 
console.log(countRange.value);


function cardPrice() {
    
}

function cardName() {

}

const createPrice = () => {

}




//При клике мыши, создается новый, который мы должны использовать в конце.
const createCard = () => {
    const newCard = document.createElement("div");
    const cardImage = document.createElement("div");
    const cardInfo = document.createElement("div");

    const cardTitle = document.createElement("h4");
    const cardPrice = document.createElement("span");
    const cardCount = document.createElement("span");

    newCard.classList.add("card")
    cardImage.classList.add("card-image")
    cardInfo.classList.add("card-info")

    cardTitle.classList.add("card-title")
    cardPrice.classList.add("card-price")
    cardCount.classList.add("card-count")

    cardTitle.textContent = titleInp.value;
    cardPrice.textContent = priceInp.value;
    cardCount.textContent = countRange.value;

    newCard.append(cardImage);
    newCard.append(cardInfo);

    cardInfo.append(cardTitle);
    cardInfo.append(cardPrice);
    cardInfo.append(cardCount);

    cardsContainer.append(newCard);



    

    

}

addBtn.addEventListener("click", createCard);

