//  console.log("Делаем запрос...");
//  setTimeout(() => {
//      console.log("Формируем ответ...");
//      const serverData = {
//          status: "succes",
//          data: [1, 2, 3],
//          flag: true,
//      }
//  
//      setTimeout(() => {
//          console.log("Данные получены");
//          console.log(serverData);
//      }, 2000);
//  }, 2000);

//Выводим запрос -- создаем тайм-оут -- выводим формирование и создаем массив данных -- после внутри создаем еще тайм-оут -- выводим и массив и консоль 

//  const promise = new Promise((resolve, reject) => {
//      setTimeout(() => {
//          console.log("Формируем ответ...");
//          const serverData = {
//              status: "succes",
//              data: [1, 2, 3],
//              flag: true,
//          }
//  
//          resolve(serverData); // resolve сработает, при успешном запросе
//      }, 2000);
//  
//  }).then((data) => {
//      console.log("Данные получены");
//      console.log(data);
//  });

//Создаем конст и обещание -- создаем тайм-оут -- выводим формирование ответа и сервер -- после используем ресолв, если запрос успешно выполнен -- тогда создаем окончательную функци дата -- выводим инфу с сервера 

//  console.log("Старт");
//  const promise = new Promise((resolve, reject) => {
//      setTimeout(() => {
//          console.log("Формируем ответ...");
//          const serverData = {
//              status: "succes",
//              data: [1, 2, 3],
//              flag: true,
//          }
//          
//          reject("Неверный запрос 400");
//          //  resolve(serverData); // resolve сработает, при успешном запросе
//      }, 2000);
//  
//  }).then((data) => {
//      console.log("Данные получены");
//      data.flag = false;
//      return data;
//  }).then((clientData) => {
//      console.log(clientData);
//  }).catch((errorMessage) => {
//      console.error("Ошибка сервера: ", errorMessage);
//  }).finally(() => {
//      console.log("Финиш");
//  });

// при ресолв - он сработает нормально, то есть выведит данные с сервера.
// при реджект - он выдаст ошибку. Ошибку можно кастомизировать.
// тогда - тогда - тогда. Цепочка работает до конца 
// при катч - выдает ошибку
// при финиш - выдает завершение функции


//  const pause = (time) => {
//      return new Promise((resolve, reject) => {
//          setTimeout(() => {
//              resolve();
//          }, time);
//      });
//  }
//  // promise.all -- принимает массив промиссов и сработает после выполнения всех промиссов
//  Promise.all([
//      pause(2000).then(() => console.log("Прошло 2 секунды")),
//      pause(4000).then(() => console.log("Прошло 4 секунды"))
//  ]).then(() => {
//      console.log("Сообщение после всех промисов");
//  });
//  
//  
//  Promise.race([
//      pause(2000).then(() => console.log("Прошло 2 секунды")),
//      pause(4000).then(() => console.log("Прошло 4 секунды"))
//  ]).then(() => {
//      console.log("Сработал промис");
//  })


//  setTimeout(() => {
//      console.log(2);
//  }, 1);
//  
//  console.log(3); // не ассинхронны
//  
//  setTimeout(() => {
//      console.log(1);
//  }, 0);
//  
//  console.log(0); // не ассинхронны
//  
//  // 3 -- 0 -- 1 -- 2


//  const fetchDataFromServer = () => {
//      return new Promise((resolve, reject) => {
//          setTimeout(() => {
//              const data = {
//                  name: "Alex",
//                  age: 22,
//              }
//              resolve(JSON.stringify(data));
//          }, 1000);
//      })
//  }
//  
//  fetchDataFromServer()
//      .then((dataFromServer) => {
//          console.log("Данные получены");
//          return JSON.parse(dataFromServer);
//      })
//      .then((data) => {
//          console.log(data);
//      })
//      .catch(() => console.error("Ошибка !"));


//  const URL = "https://jsonplaceholder.typicode.com/todos";
//  
//  const getData = () => {
//      const res = fetch(URL, {
//          method: "GET"
//      });
//      const todosArr = [];
//      res.then((dataFromServer) => {
//          console.log(dataFromServer);
//          return dataFromServer.json();
//      }).then((data) => {
//          console.log(data);
//          data = console.log(data[0].id);
//      })
//      res.catch((errorMessage) => {
//          console.error("Ошибка", errorMessage);
//      })
//  }
//  
//  getData();








const container = document.querySelector(".container");
const searchForm = document.querySelector("#search-car");
const searchInput = document.querySelector("#car-name");
const carClassesSelect = document.querySelector("#car-classes-select");
const trucks = document.querySelector(".trucks");
const pagination = document.querySelector(".pagination");




const carsURL = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/all-vehicles-model/records?limit=20&refine=make%3A%22Ford%22";

let carName = "Ford";

let totalPaginationBtns = 10;
let pageLimit = 10;
let carsData;
let currentOffset = 10;
let minPagination = 1;
let maxPagination = 10;


const getData = (carName, offset, pageLimit = 10) => {
    const res = fetch(`https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/all-vehicles-model/records?limit=${pageLimit}&refine=make%3A%22${carName}%22`, {
        method: "GET",
        headers: {
            "accept": "application/json"
        }
    });

    res.then((dataFromServer) => dataFromServer.json())
        .then((data) => {
            showCars(data.results);
            createPagination(data.total_count);
        })
        .catch((errorMessage) => {
            console.error("Ошибка", errorMessage);
        })
}


const getAllCarTypes = (carsArr) => {
    const carTypesSet = new Set;
    carsArr.forEach((car) => {
        carTypesSet.add(car.vclass);

    });
    console.log(Array.from(carTypesSet));
    return Array.from(carTypesSet);
}













const createCarCard = (car) => {
    const card = `
    <div class="car-card" data-car-type="${car.vclass}">
        <h2>${car.make}</h2>
        <h3>${car.basemodel}</h3>
        <ul>
            <li>${car.createdon}</li>
            <li>${car.drive}</li>
            <li>${car.fueltype}</li>
        </ul>

    </div>
    `;
    container.insertAdjacentHTML("beforeend", card);

}

const fillDropDownMenu = (carTypesArr) => {
    if (carTypesArr.length > 0) {
        carClassesSelect.innerHTML = "";
    }

    carTypesArr.forEach((carType) => {
        const carTypeOption = `
            <option value="${carType}">${carType}</option>
        `;
        carClassesSelect.insertAdjacentHTML("beforeend", carTypeOption);
    })
    

}

const showCars = (carsData) => {
    console.log(carsData);
    if (carsData.length > 0) {
        container.innerHTNL = "";

    }
    carsData.forEach((car) => {
        createCarCard(car);
    });

    const carTypesArr = getAllCarTypes(carsData);
    fillDropDownMenu(carClassesSelect)
    console.log(carTypesArr);
}

searchForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const value = searchInput.value;
    getData(value, currentOffset, pageLimit);
});


console.log(carClassesSelect);
carClassesSelect.addEventListener("change", () => {
    const allCards = document.queryCommandValue(".car-card");
    const carClassesSelectValue = carClassesSelect.value;
    allCards.forEach((card) => {
        const carCardType = card.dataset.carType;
        if (carCardType !== carClassesSelectValue) {
            card.style.display = "none";
        } else {
            card.style.display = "block";
        }
    })
});



const createPagination = (totalCarsCount) => {
    const btnsCount = Math.floor(totalCarsCount / pageLimit);
    



    for (let i = minPagination; i <= maxPagination; i++) {
        const paginationBtn = document.createElement("button");
        paginationBtn.textContent = i;
        pagination.append(paginationBtn);
    }
}

pagination.addEventListener("click", (event) => {
    const target = event.target;
    const btn = target.closest("button");

    if(btn) {
        const carName = searchInput.value;
        console.log(btn.textContent);
        getData(carName, currentOffset * +btn.textContent, pageLimit);
    }
})


