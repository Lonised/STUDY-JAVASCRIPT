// let - создаем переменную -> после даем её имя, -> знак присваивания = -> записываем значения 

//Числовой тип данных - number 
//let userAge = 16;
//let userWeight = 100;
//let userHeight = 190;

//Выводит сообщение для пользователя 
//alert("Hello world!");
//alert("Возраст пользователя = ");
//alert(userAge);

//confirm("Сегодня был дождь ?");

//prompt("Сколько время ?");

//То, что ввел пользователь в окно prompt, записываем в переменную 
//let userName = prompt("Введите ваше имя");

//alert("Hello, " + userName); 

//Тип данных string (строка или текст)
//let text = " 'Lorem ipsum dollar.' "
//Когда складываются две строки - происходит конкатенация (Сложение строк)
//alert(text);
//alert(text + " Еще текста...");

//Пусть пользователь добавит в переменную text, свою строку 

//let words = prompt("name")

//alert(text + words)

//let text = "Lorem";
//alert(text);
//Перезаписали значение переменной 
//text = text + prompt("Введите еще текста");
//alert(text)


//Логический тип данных - Boolean

//let showElem = true; //истина
//let isRed = false; //Ложь

//alert(showElem);

// typeof() - Определяет тип данных у переменной, которую мы запишем в круглых скобках 
//alert( typeof(showElem) ); // boolean
//alert( typeof("Hello") ); // string
//alert( typeof(400) ); //number
//alert( typeof(-56) ); //number
//alert( typeof(1/2) ); //number


//Всегда получаем строчку
//let num1 = prompt("Введите число 1");
//let num2 = prompt("Введите число 2");

//let num1 = +prompt("Введите число 1");
//let num2 = +prompt("Введите число 2");
//let num3 = Number("15"); 

//console.log(num1 + num2 + num3);

//console.log(num1 + num2); 
//console.log(num1 - num2);
//console.log(num1 * num2);
//console.log(num1 / num2);

//console.log(num1 ** num2); //Возведем в степень 
//console.log(6 % 2); //%Остаток при делении 

//console.log(2 * (num1 + num2) / 3);
//console.log();



//1 
//let num1 = +prompt("Введите число:")
//console.log("Степень = ", num1 ** 2);
//
////2 
//let num2 = +prompt("Введите первое число:")
//let num2a = +prompt("Введите первое число:")
//console.log((num2 + num2a) / 2);
//
////3 
//let num3 = +prompt("Введите длину:")
//console.log("Площадь квадрата равна = ", num3 * num3);
//
////4 
//let num4 = +prompt("Введите число:")
//console.log("Километры в мили = ", num4 * 0,62);
//
////5 
//let num5 = +prompt("Введите первое число:")
//let num5a = +prompt("Введите первое число:")
//console.log("Сложение", num5 + num5a); 
//console.log("Вычитание", num5 - num5a);
//console.log("Умножение", num5 * num5a);
//console.log("Деление", num5 / num5a);
//
////6 
//let num6 = +prompt("Введите значение a:")
//let num6a = +prompt("Введите значение b:")
//let num6b = x
//console.log("X равен = ", num6 * num6b + num6a == 0);
//
////7 
//let num7 = +prompt("Введите час:")
//let num7a = +prompt("Введите минуты:")
//console.log("Времени осталось до следующего дня = ", 24 - num7, //":", 60 - num7a);
//
////8 
//let num8 = +prompt1("Введите трехзначное число:")
//let num8a = +prompt("")
//console.log("Остаток от деления = ", num8 % num8a);

////9
//let a = prompt("Введите значение a:")
//let b = prompt("Введите значение b:")
//let c = prompt("Введите значение c:")
//let d = prompt("Введите значение d:")
//let e = prompt("Введите значение e:")
//console.log(a,b,c,d,e, "=", e,b,c,d,a);
//
////10 
//let num10 = $250
