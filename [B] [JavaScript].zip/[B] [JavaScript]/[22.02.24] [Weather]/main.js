//  // https://developer.mozilla.org/en-US/docs/Web/HTTP/Status
//  
//  const usersContainer = document.querySelector(".users-container");
//  
//  const usersURL = "https://jsonplaceholder.typicode.com/users";
//  const postUserURL = "/posts";
//  
//  const getData = (url) => {
//  
//      const xhr = new XMLHttpRequest();
//      let data = null;
//      // GET - получить. POST - записать 
//      xhr.open("GET", url);
//      xhr.addEventListener("load", () => {
//          // response - ответ 
//          if (xhr.status === 200) {
//              data = JSON.parse(xhr.response);
//  
//              data.forEach(userObject => {
//                  console.log(userObject);
//                  insertUserCard(userObject);
//              });
//          }
//          
//      });
//  
//      xhr.send();
//      
//  };
//  
//  
//  
//  
//  const postData = (url) => {
//      const xhr = new XMLHttpRequest();
//  
//      const newUser = {
//          name: "Test",
//          age: 44,
//      };
//      
//      xhr.open("POST", url);
//  
//      xhr.addEventListener("load", () => {
//          console.log("Данные успешно записаны");
//          console.log(xhr.response); 
//      });
//  
//      //  xhr.send(JSON.stringify(newUser));
//  
//  
//  };
//  
//  
//  const insertUserCard = (user) => {
//      const userCard = `
//          <div class="user">
//  
//              <div class="user-header">
//  
//                  <span>${user.id}</span>
//                  <span>${user.name}</span>
//  
//              </div>
//  
//              <div class="user-info">
//  
//                  <a href="malito:${user.email}">${user.email}</a>
//                  <a href="tel:${user.phone}">${user.phone}</a>
//  
//              </div>
//  
//              <div class="user-company">
//  
//                  <span>${user.company.name}</span>
//                  <span>${user.company.catchPhrase}</span>
//                  <span>${user.company.bs}</span>
//  
//              </div>
//  
//          </div>
//      `;
//      usersContainer.insertAdjacentHTML("beforeend", userCard);
//  
//  };
//  
//  getData(usersURL);
//  postData(postUserURL);

const API_KEY = "a9364650d7bb1a7f29a975686cbc4543";
const weatherURL = "https://api.openweathermap.org/data/2.5/weather?";

const weatherCard = document.querySelector(".weather-card");



const getWeather = () => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `${weatherURL}q=Karaganda&appid=${API_KEY}&units=metric&lang=RU`);

    xhr.addEventListener("load", () => {
        console.log(JSON.parse(xhr.response));
    });

    xhr.send();
}

getWeather();



const weatherBtn = document.getElementById("weather-btn");
const weatherInput = document.getElementById("city-name")


const insertWeatherCard = (user) => {
    const weatherCard = `
    <div class="weather-card">

            <div class="weather-city">

                <span>${weather.city}</span>

            </div>

            <div class="weather-temp">

                <span>${user.temp}</span>

            </div>

            <div class="weather-feel-temp">

                <span>${weather.fell.temp}</span>

            </div>

        </div>
    `;
    
}

insertWeatherCard();