//  const car = {
//      speed: 100,
//      Fuel: 14,
//      color: "red",
//  }
//  
//  for (const key in car) {
//      // console.log("Ключ: ", key, "Значение: ", car[key]); //
//      // Второй способ полегче // 
//      console.log(`Ключ: ${key}. Значение: ${car[key]}.`);
//  }


//=========================Функции==========================//

//  function getNumbers() {
//      let num = +prompt("Число 1");
//      let num2 = +prompt("Число 2");
//  
//      let sum = num + num2;
//      console.log(sum);
//  
//      return sum; //  Вернуть значение из нашей функции
//  }
//  
//  //  getNumbers();
//  //  Вывел простые цифры, числа, которые задал пользователь
//  
//  let numbersSum = getNumbers();
//  console.log(numbersSum);

//__________________________________________________________//

//  function calcSum(num1, num2) {
//      let sum = num1 + num2;
//      console.log(`num1 = ${num1}, num2 = ${num2}`);
//  
//      return sum;
//  }
//  
//  let result = calcSum(10, 15);
//  calcSum(50, 60);
//  calcSum(-3, 0);
//  calcSum(+prompt(), +prompt());
//  calcSum(result, 0);

//__________________________________________________________//

//  function calc(a, b, sign) {
//      if (sign == "+") {
//          console.log(a + b);
//          return a + b;
//      } else if (sign == "-") {
//          console.log(a - b);
//          return a - b;
//      } else if (sign == "*") {
//          console.log(a * b);
//          return a * b;
//      } else if (sign == "/") {
//          console.log(a / b);
//          return a / b;
//      } else {
//          console.log("Error!");
//      }
//  }

//  calc(5, 4, "+");
//  calc(+prompt(), +prompt(), prompt("+ - * /"))


//  function test() {
//      console.log(1);
//      return "Test";
//      console.log(2);
//  }
//  
//  test();

//__________________________________________________________//

//  function showArray(arr) {
//      for (let i = 0; i < arr.length; i++) {
//          console.log(arr[i]);
//      }
//  }
//  
//  showArray([5,7,834,275]);
//  showArray(["Hello", "Привет"]);
//  showArray([{test: 111}, {test: 222}]);
//  
//  let arr = []; //Сюда мы добавляем свои переменные
//  let counter = 0;
//  
//  function fillArray(value) {
//      counter++;
//      arr.push(value);
//      console.log(`${value} успешно добавлено в массив arr.
//      Массив = ${arr}`);
//  
//      console.log(`Функция вызывалась ${counter} раз`);
//  } 
//  
//  fillArray("red");
//  fillArray("blue");
//  fillArray("green");
//  fillArray("orange");

//__________________________________________________________//

//  //isOdd говорит нам о том, какие нужны числа (четные, нечетные)
//  function showNumbers(a, b, isOdd) {
//      for (let i = a; i <= b; i++) {
//          if (isOdd == true && i % 2 != 0) { 
//              console.log(i);
//          } else if (isOdd != true && i % 2 == 0) {
//              console.log(i);
//          }
//      }
//  
//  }
//  
//  showNumbers(10, 20, true);
//  showNumbers(10, 20, false);

//__________________________________________________________//

//  function isSimple(number) {
//      if (number <= 1) {
//          return false;
//      }
//  
//      for (let i = 2; i <= number / 2; i++) {
//          if (number % i == 0) {
//              console.log("Число", number, "Не простое");
//              return false;
//          }
//      }
//      console.log("Число", number, "простое");
//      return true;
//  }
//  isSimple(4)

//=========================Повторение массива==========================///

//  const arr = [5, 624, 7, 836, 46];
//  
//  //  let deletedElem = arr.pop(); //Удаляет последний элемент 
//  //  arr.push(5); //Вспоминает удаленный элемент
//  //  console.log(deletedElem); //Выводит 
//  
//  arr.reverse(); //Делает реверс
//  console.log(arr);
//  
//  const arr2 = [10, 20, 30];
//  
//  const concatedArr = arr.concat(arr2); //Объединяет массивы
//  console.log(concatedArr);
//  
//  let sorted = arr.sort();
//  console.log(sorted);
//  
//  const testArr = [3, 2, 1, 10, 11, 23]
//  //  console.log(testArr.sort()); //Сортирует 
//  
//  let sectionArr = testArr.slice(1, 3);
//  let sectionArr1 = testArr.slice(2, testArr.length);
//  console.log(sectionArr);
//  console.log(sectionArr1)
//  
//  const stringFromArray = testArr.join("--"); //Разделитель 
//  console.log(stringFromArray);
//  
//  let string = "шалаш на дереве"; //Каждая буква - это элемент массива 
//  let wordArr = string.split("");
//  console.log(wordArr);

//__________________________________________________________//

//  function isPolidrom(word) {
//      let wordArr = word.split("");
//      let reversedWordArr = wordArr.reverse();
//      let reversedString = reversedWordArr.join("");
//  
//      console.log(reversedString);
//  
//      if (word == reversedString) {
//          console.log("Является Полидромом");
//      } else if (word != reversedString) {
//          console.log("Не является Полидромом");
//      }
//  
//      
//  }
//  
//  isPolidrom("Привет");
//  isPolidrom("шалаш");

//__________________________________________________________//

// Массивы сравниваются по ссылке 

let test = [1, 2, 3];
let arr = [1, 2, 3];

let testCopy = test; //Не копируем, а сохраняем только ссылку на него 

console.log("Test: ", test);
console.log("TestCopy: ", testCopy);

test.push(4);
testCopy.push(10)

console.log("Test: ", test);
console.log("TestCopy: ", testCopy);

if (test == testCopy) {
    console.log("Они правы");
} else {
    console.log("Не равны");
}