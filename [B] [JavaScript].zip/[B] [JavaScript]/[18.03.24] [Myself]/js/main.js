const addFigure = document.querySelector('.start-figure');
const deleteFigure = document.querySelector('.end-figure')
const figure = document.querySelector('.example');

addFigure.addEventListener('click', () => {
    figure.style.display = 'block';

});

deleteFigure.addEventListener('click', () => {
    figure.style.display = 'none';
});




function changeSquareAngle() {
    const TopLeftRange = document.querySelector('.top-left-range').value;
    const TopRightRange = document.querySelector('.top-right-range').value;
    const BottomLeftRange = document.querySelector('.bottom-left-range').value;
    const BottomRightRange = document.querySelector('.bottom-right-range').value;

    const angle = (parseInt(TopLeftRange) + parseInt(TopRightRange) + parseInt(BottomLeftRange) + parseInt(BottomRightRange)) / 4;

    const example = document.querySelectorAll('.example');
    example.forEach(function(example) {
        example.style.transform = 'rotate(' + angle + 'deg)';

    });

    document.querySelectorAll('.middle-range').forEach(function(range) {
        range.addEventListener('input', changeSquareAngle);
    });
}



const middleRange = document.getElementById("middle-range");


let СreateMyFigure = function(){
	document.getElementById('builder-example').style.borderRadius = middleRange.value + "px";
	document.getElementById('example').innerHTML = figure.value;

}
document.getElementById('middle-range').addEventListener('input', function(){		
	СreateMyFigure();
});	
СreateMyFigure();